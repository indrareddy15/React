import express from 'express';
import Question from '../models/Question.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

// Get all questions
router.get('/', async (req, res) => {
  try {
    const questions = await Question.find()
      .populate('author', 'username')
      .sort({ createdAt: -1 });
    res.json({ questions });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get a specific question
router.get('/:id', async (req, res) => {
  try {
    const question = await Question.findById(req.params.id)
      .populate('author', 'username')
      .populate({
        path: 'answers',
        populate: { path: 'author', select: 'username' }
      });
    
    if (!question) {
      return res.status(404).json({ message: 'Question not found' });
    }
    
    // Increment views
    question.views += 1;
    await question.save();
    
    res.json(question);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create a question
router.post('/', auth, async (req, res) => {
  try {
    const { title, body, tags } = req.body;
    const question = new Question({
      title,
      body,
      tags,
      author: req.userId
    });
    
    await question.save();
    res.status(201).json(question);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update a question
router.patch('/:id', auth, async (req, res) => {
  try {
    const question = await Question.findById(req.params.id);
    
    if (!question) {
      return res.status(404).json({ message: 'Question not found' });
    }
    
    if (question.author.toString() !== req.userId) {
      return res.status(403).json({ message: 'Not authorized' });
    }
    
    const { title, body, tags } = req.body;
    if (title) question.title = title;
    if (body) question.body = body;
    if (tags) question.tags = tags;
    
    await question.save();
    res.json(question);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete a question
router.delete('/:id', auth, async (req, res) => {
  try {
    const question = await Question.findById(req.params.id);
    
    if (!question) {
      return res.status(404).json({ message: 'Question not found' });
    }
    
    if (question.author.toString() !== req.userId) {
      return res.status(403).json({ message: 'Not authorized' });
    }
    
    await question.deleteOne();
    res.json({ message: 'Question deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Vote on a question
router.post('/:id/vote', auth, async (req, res) => {
  try {
    const { voteType } = req.body; // 'up' or 'down'
    const question = await Question.findById(req.params.id);
    
    if (!question) {
      return res.status(404).json({ message: 'Question not found' });
    }
    
    question.votes += voteType === 'up' ? 1 : -1;
    await question.save();
    
    res.json(question);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

export default router;