var a = 10;

console.log(a);

if(a==10)
  {
      const a = 20;
      console.log(a);
  }
var a = 30;

console.log(a);