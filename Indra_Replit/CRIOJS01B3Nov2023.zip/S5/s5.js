// let todoDB = [];
// function addTodo(item, priority) {
//   if (priority === "high") {
//     todoDB.unshift(item);
//   } else {
//     todoDB.push(item);
//   }
// }

// addTodo("Item 1", "low");
// addTodo("Item 2", "low");
// addTodo("Item 3", "high");

// console.log(todoDB);


// const arr = [1, "Kevin", null, 0, true];
// for (var itr = 0; itr < arr.length; itr++) {
//   if (arr[itr] !== null && arr[itr] !== 0)
//     console.log(arr[itr]);
// }

// const arr1 = [1,2,3,4,5,6,7,8,9];

// console.log(arr1.filter((num) => num % 2 === 0));
// console.log(arr1.includes(5, 8));

// let str = "Today is Session 5 of JS-1";
// console.log(str.split(" "));
// let arr = ['Today', 'is', 'Session', '5', 'of', 'JS-1'];
// console.log(arr.join(" "));
// console.log(arr.join("-"));
// console.log(arr.join("_"));

