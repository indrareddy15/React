// const obj = {}

// obj.name = 'John'
// obj.age = 30
// obj.city = 'New York'
// obj.country = 'USA'
// obj.isMarried = false
// obj.skills = ['HTML', 'CSS', 'JS']
// obj.sayHello = function() {
//   console.log('Hello')
// }

// console.log(obj)

// let name = "Crio"
// let ob = {name: "Criodo"}
// console.log(ob.name) // 1
// console.log(ob[name]) // 2


// let obj = {
//   firstName: "Indra",
//   lastName: "Reddy"
// }

// // obj.fullName = obj.firstName + obj.lastName
// obj.fullName = `${obj.firstName} ${obj.lastName}`

// console.log(obj);


// const personalDetails = {
//    name: "John Doe",
//    designation: "Data Analyst",
//    isEngineer: true
// }
// if(personalDetails.isEngineer)
//     console.log("Property exists");
// else
//     console.log("Property doesn't exists");

// const personalDetails = {
//    name: "John Doe",
//    designation: "Data Analyst",
//    isEngineer: false
// }
// if(personalDetails.isEngineer)
//     console.log("Property exists");
// else
//     console.log("Property doesn't exists");

// const person = {
//   name: "Indra",
//   jobTitle: "SD",
//   email: "abc@gmail.com",
//   isVarified: false
// }

// console.log(person.name, person.isVarified);

// const person = {
//   name: "Indra",
//   jobTitle: "SD",
//   email: "abc@gmail.com",
//   isVarified: false
// }

// console.log(person);
// console.log(person.name, person.isVarified);
// console.log(person.isVarified = true);
// console.log(person)
// delete person.name;
// person.firstName = "Indra";
// person.lastName = "Reddy";
// console.log(person)


// const data = {
//   name: "Indra",
//   age: 23,
//   role: "SD",
//   address: {
//     street: "Kp",
//     pincode: 522529,
//     city: "Guntur",
//     landMark: "CGGBank",
//     country: "India"
//   }
// }
// console.log(data.address.landMark)
// console.log(data.address.country);
// console.log(data.address);

// const personalDetails = {
//    name: "John Doe",
//    designation: "Data Analyst",
//    age: 24,
//    address: {
//       locality: "1600 roselane colony",
//       city: "Mumbai",
//       state: "Maharashtra",
//       country: "India"
//    }
// }
// console.log (personalDetails.address.city); //2
// console.log(personalDetails['address']['city']);//2
// console.log (personalDetails.address);

const userDetails = {
  name: {
    first: "Kapil",
    last: "Raghuwanshi",
  },
  jobTitle: "JS Instructor @ Crio.do",
  email: {
    work: "kapil@epsilon.com",
    personal: "",
  },
  status: {
    isOnline: true,
    isVerified: false,
  }
}
userDetails.name.first = "Indra";
userDetails.name.last = "Reddy";
userDetails.jobTitle = "SD";
userDetails.email.work = "tugrp@example.com";
userDetails.email.personal = "xcvkp@example.com";
userDetails.status.isProMember = false;
console.log(userDetails);
console.log(JSON.stringify(userDetails));
