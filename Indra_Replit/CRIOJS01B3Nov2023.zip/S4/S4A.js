let i = 0;
for(j = i+1; j<=10; j++) {
  console.log(j);
}