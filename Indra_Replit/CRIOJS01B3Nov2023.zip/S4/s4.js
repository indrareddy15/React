// const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9]

// console.log(arr.sort());
// console.log(arr.reverse());

// // for(i = 0; i < 3; i++){
// //   console.log(i)
// // }

// let i = 0;
//  console.log(i)
//  console.log(i++)
//  console.log(++i)

// function sum(n) {
//   let sum = 0
//     for(i = 1; i <= n; i++){
//       sum += i;
//     }
//     return sum;
// }

// sum(3)
// console.log(sum(3))

// const arr = [1 , "Hello" , true, [1 ,2], {}, () => {console.log("Hello")}]

// console.log(arr[2])
// arr[2] = 100
// console.log(arr[2])
// console.log(arr[5])

// const arr = [];
// arr[0] = 1;
// arr[1] = "Hello";
// arr[2] = null;
// arr[3] = true;
// arr[4] = "Piotr";
// console.log(arr[1]);
// arr[4] = "Indra";
// console.log(arr);
// console.log(arr[4]);


// let i = 0;
// for(j = i+1; j>=10; j--) {
//   console.log(j);
// }

// const arr = [1 , 2 , 3 , 4 , 5 , 6 , 7]
// console.log(arr[-1]);

// for(i = 0; i < arr.length; i++){
//   console.log(arr[i])
// }

//falsy values

// fasle
// 0
// ""
// null
// undefined

// let x = [1, 2, 3]
// let y = x
// x[0] = 1000

// console.log(x)
// console.log(y)

// let a = [1, 2, 3]
// let b = [1, 2, 3]
// let c = a

// console.log(a === b) 				 
// console.log(a === c)


// console.log(a == b)
// console.log(a == c)

// let arr = [1, 2, 3, 4, 5]

// console.log(arr.push(6));
// console.log(arr.unshift(0));
// console.log("OLDArray", arr);


// console.log(arr.pop());
// console.log(arr.shift());
// console.log("NEWArray", arr);

const arr = [1, "Kevin", null, 0, true];
for(var itr = 0; itr < arr.length; itr++ ){
      if(arr[itr] !== null && arr [itr] !== 0)
          console.log(arr[itr]);
}
