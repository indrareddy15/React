let HSC_MARKS = 85;
let CET_MARKS = 80;

function getAdmission(hsc, cet) {
  if (hsc >= 80) {
    if (cet > 90) {
      return "You are admitted to Govt College";
    } else if (cet > 80 && cet < 90) {
      return "You are admitted to autonomous Private College";
    } else {
      return "You are admitted to Private College";
    }
  } else {
    return "You are not eligible for admission";
  }
}

console.log("getAdmission", getAdmission(HSC_MARKS, CET_MARKS));

let str = "DataLength";

console.log(str.length);
console.log(str.toUpperCase());
console.log(str.toLowerCase());
console.log(str.charAt(0));
console.log(str[0]);
console.log(str.indexOf("a"));
console.log(str.lastIndexOf("a"));
console.log(str.substring(0, 5));
console.log(str.slice(0, 5));
console.log(str.split(" "));
console.log(str.replace("Data", "Data Length"));
console.log(str.includes("Data"));
console.log(str.startsWith("Data"));
console.log(str.endsWith("Length"));
console.log(str.match(/Data/));

const strs = "Rahul, Kiran";
console.log(strs.length);
console.log(strs[0]);
console.log(strs[7]);
console.log(strs[0] + strs[7]);
const data = strs[0] + strs[7];
console.log(data);

const firstName = "Indra";
const lastName = "Reddy";
const greeting = `My name is ${firstName} ${lastName}.
What’s yours? “Long time”! `;
console.log(greeting);

const item = [
  "issuer.id",
  "issuer.cik",
  "issuer.name",
  "issuer.primarySymbol",
  "issuer.entityTypes",
  "issuer.subSector",
  "issuer.sector",
  "issuer.description",
  "issuer.primaryCusip",
  "issuer.isDefunct",
  "issuer.naics",
  "issuer.headquarters",
  "issuer.offerings.securityType",
  "issuer.offerings.publicFilingDate",
  "issuer.offerings.pricingDate",
  "issuer.offerings.firstTradeDate",
  "issuer.offerings.settlementDate",
  "issuer.offerings.grossSpreadTotal",
  "issuer.offerings.lastTradeBeforeFiling",
  "issuer.offerings.maturityDate",
  "issuer.offerings.status",
  "issuer.offerings.type",
  "issuer.offerings.exchange",
  "issuer.offerings.launchDate",
  "issuer.offerings.hasForwardAgreement",
  "issuer.offerings.postponedDate",
  "issuer.offerings.withdrawnDate",
  "attributes.price",
  "attributerized",
  "attributes.preOfferingShares",
  "attributes.marketCapPreOfferingUsd",
  "attributes.marketCapPreOffering",
  "attributes.marketCapAtPricingUsd",
  "attributes.marketCapAtPricing",
  "attributes.pctMarketCapPreOffering",
  "attributes.pctMarketCapAtPricing",
  "attributes.latestGrossProceedsBaseUsd",
  "attributes.latestGrossProceedsBase",
  "attributes.latestGrossProceedsTotalUsd",
  "securityType",
  "publicFilingDate",
  "pricingDate",
  "firstTradeDate",
  "settlementDate",
  "grossSpreadTotal",
  "lastTradeBeforeFiling",
  "maturityDate",
  "status",
  "type",
  "exchange",
  "launchDate",
  "hasForwardAgreement",
  "postponedDate",
  // ... (your item array remains the same)
];
