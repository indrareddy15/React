const todoDB = [];

function addTodo(arr, item, priority) {
  
}

function clearTodo(arr, index) {
   
}

function updateTodo(arr, index, newItem) {
   
}

function getTodo(arr, index) {
  
}