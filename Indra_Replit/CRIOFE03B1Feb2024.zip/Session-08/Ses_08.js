// 21th Feb 2024 CRIO_FE-03_B1_Session-08
// console.log("Welcome to Session-08");

// function run(x) {
//   x = x + 10
//   console.log(x)
//   return x
// }

// run(10)

// Functional Programming
// function run(x) {
//   let y = x + 10;
//   console.log(y);
//   return y;
// }

// run(10);

// imperative vs Declarative
// const passwords = [
//   "123456",
//   "password",
//   "admin",
//   "helloworld",
//   "mypassword123",
// ];

// let lenPwd = [];

// for (let i = 0; i < passwords.length; i++) {
//   const pwd = passwords[i];
//   if (passwords.length >= 9) {
//     lenPwd.push(pwd);
//   }
// }
// console.log("pwd", lenPwd);

// const byTwo = function(x){
//   let y = x / 2;
//   return y
// }

// const ans = byTwo(10);
// console.log(ans)

// var a =2;

// function run(a) {
//   a = a + 10;
//   return a;
// }

// console.log(run(a))

// const arr1 = [1,2,3,4,5];
// const arr2 = arr1
// const arr3 = [...arr1]
// console.log(arr2)


// When you accept a function as an argument, you are not calling the function, you are passing it to another function. then it is called as a callback function

// Higher order fucntion : when you accept

function add(x,y){
  return x + y
}

function subtract(x , y){
  return x - y
}

function calc(fun, x, y) {
  return fun(x ,y)
}

console.log(calc(add, 2 , 3))
console.log(calc(subtract, 2 , 3))