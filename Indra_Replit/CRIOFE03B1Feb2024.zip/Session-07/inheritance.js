


class Student {
  constructor(name) {
    this.name = name;
  }

  markAttendence() {
    console.log("Student " + this.name + " is Present");
  }
}

class SportsCaption extends Student {
  markAttendence() {
    super.markAttendence();
    console.log("Method Overriding concept " + this.name + " is Present");
  }

  playFootball() {
    console.log("Student " + this.name + " is playing Football");
  }
}

const sc = new SportsCaption("Indra");
sc.markAttendence();

class New extends SportsCaption {
  markAttendence() {
    console.log("Child Process of Method Overriding concept " + this.name);
  }
}

class C extends Student {
  dataFun() {
    console.log("Hello World " + this.name);
  }
}

// const sc = new New("Indra");
// sc.markAttendence();

// const stuObj = new Student("Rahul");
// stuObj.markAttendence()

// const sc = new SportsCaption("Indra");
// sc.markAttendence();
// sc.playFootball();




// class Student {
//   constructor(name) {
//     this.name = name;
//   }

//   markAttendence() {
//     console.log("Student " + this.name + " is Present");
//   }
// }

// class SportsCaption extends Student {
//   constructor(name, batch) {
//     super(name);
//     this.batch = batch;
//   }
//   markAttendence() {
//     console.log("Super concept " + this.name + " is Present");
//   }

//   playFootball() {
//     console.log("Student " + this.name + " is playing Football");
//   }
// }

// const sc = new SportsCaption("Indra", "Batch-2");
// // console.log(sc);
// sc.markAttendence();
// sc.playFootball();

