// 19th Feb 2024 CRIO_FE-03_B1_Session-07
// console.log("Welcome to Session-07");

// const obj = {
//   "key": "value",
//   "key1": "value1",
//   "key2": "value2",
//   "key3": "value3",
// };

// console.log(Object.keys(obj));
// console.log(Object.values(obj));
// console.log(Object.entries(obj));
// console.log(Object.length(obj));

// let arr = [];
// for (let i in obj) {
//   arr.push(obj[i]);
// }

// console.log(arr);
// const data = {...obj}
// console.log(data)

// console.log(Object.keys(obj));
// console.log(Object.values(obj));
// console.log(Object.entries(obj))
// console.log(new Object)
// console.log()

// const employeeData = {
//   John: 100,
//   Pete: 300,
//   Mary: 250,
// };

// class Util {
//   constructor(employeeData) {
//     this.emplydata = employeeData;
//   }

//   sumSaliris = () => {
//     // console.log("Sum Salaries");
//     const salaries = Object.values(this.emplydata);
//     // console.log("salaries", salaries);
//     const sum = salaries.reduce((a, b) => a + b, 0);
//     // console.log("sum", sum);
//     return sum;
//   };

//   averageSaliries = () => {
//     const totalSal = this.sumSaliris();
//     const totalEmp = Object.keys(this.emplydata).length;

//     const average = totalSal / totalEmp;
//     return average;
//   };

//   findSalaryRange = () => {
//     //max and min
//     const salaries = Object.values(this.emplydata);
//     const max = Math.max(...salaries);
//     const min = Math.min(...salaries);
//     return max - min;
//   };
// }

// const objectUtil = new Util(employeeData);
// const sum = objectUtil.sumSaliris();
// const avg = objectUtil.averageSaliries();
// const range = objectUtil.findSalaryRange();
// console.log(range);

// class Friut{
//   constructor(name, taste){
//     this.name = name;
//     this.taste = taste;
//   }

//   getFriutName = () => {
//     return "Friut name is " + this.name;
//   }

//   getTaste = () => {
//     return "Friut taste is " + this.taste;
//   }
// }

// class Employee {
//   constructor(name,dept) {
//     this.name = name;
//     this.dept= dept;
//   }

//   markPresent = () => {
//     console.log(this.name + " is Present");
//   }
// }

// class Friut {
//   constructor(name, taste) {
//     this.name = name, 
//     this.taste = taste;
//   }

//   getName = () => {
//     return "Friut name is " + this.name;  
//   }

//   getTaste = () => {
//     return "Friut taste is " + this.taste;
//   }
// }

// const fruitObj = new Friut("Apple", "Sweet")
// console.log(fruitObj.getName())
// console.log(fruitObj.getTaste())


