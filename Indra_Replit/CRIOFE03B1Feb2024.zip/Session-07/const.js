class Animal {
  constructor(name) {
    this.name = name;
  }

  makeSound() {
    console.log(this.name + " is making sound");
  }
}

class Cat extends Animal {
  constructor(name, color) {
    super(name);
    this.color = color;
  }

  getColor() {
    console.log(this.name + " is " + this.color);
  }
}

class Dog extends Animal {
  constructor(color, bread) {
    super(color);
    this.bread = bread;
  }

  getBread() {
    console.log(this.name + " Cross bread " + this.bread);
  }
}

const newani = new Dog("Buddy", "Grey", "Golden Retriever");
console.log(newani);
