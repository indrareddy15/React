// Method Overriding

class Animal {
  constructor(name) {
    this.name = name;
  }

  makeSound() {
    console.log(this.name + " is making sound");
  }
}

class Dog extends Animal {
  makeSound() {
    // super.makeSound()
    console.log(this.name + " Woof woof!");
  }
}

class Cat extends Animal {
  makeSound() {
    // super.makeSound()
    console.log(this.name + " Meow meow!");
  }
}

const dog = new Dog("Buddy", "Golden Retriever");
const cat = new Cat("Whiskers", "Gray");

// Calling overridden methods
dog.makeSound(); // Output: Woof woof!
cat.makeSound(); // Output: Meow!
