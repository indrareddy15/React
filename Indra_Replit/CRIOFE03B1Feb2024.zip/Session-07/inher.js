// Inheritance

class Animal {
  constructor(name, color, gender) {
    this.name = name;
    this.color = color;
    this.gender = gender;
  }

  makeSound() {
    console.log(this.name + " is making sound");
  }

  getColor() {
    console.log(this.name + " is " + this.color);
  }
}

class Cat extends Animal {
  getBread() {
    console.log(this.name + " Cross bread");
  }
}

class WildAni extends Animal {
  getGender() {
    console.log(this.name + " is " + this.gender);
  }
}

class WildAnimal extends Cat {
  getSameBread() {
    console.log(this.name + " is same bread as Cat");
  }
}

// const ani = new Animal("Dog", "Brown");
// console.log(ani);
// ani.makeSound();
// ani.getColor();

const ani = new WildAnimal("Lion", "Brown", "Male");
// ani.makeSound();
// ani.getColor();
ani.getBread();
// ani.getGender();
ani.getSameBread()
