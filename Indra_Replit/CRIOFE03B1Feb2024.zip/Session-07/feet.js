class Length {
  constructor(ft, inch) {
    this.ft = ft;
    this.inch = inch;
  }

  isValidObject(lengthObj) {
    return lengthObj.ft >= 0 && lengthObj.inch >= 0;
  }

  addLength(lengthObj) {
    if (!this.isValidObject(this) || !this.isValidObject(lengthObj)) {
      return [0, 0];
    }

    let totalInches = this.inch + lengthObj.inch;
    let totalFeet = this.ft + lengthObj.ft;

    if (totalInches >= 12) {
      totalFeet += Math.floor(totalInches / 12);
      totalInches %= 12;
    }

    return [totalFeet, totalInches];
  }
}

// Example usage
const length1 = new Length(5, 11);
const length2 = new Length(2, 8);
const sum = length1.addLength(length2);

console.log(sum); // Output: [8, 7]
