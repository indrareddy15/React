// class Employee {
//   constructor(name, dept) {
//     this.name = name;
//     this.dept = dept;
//   }

//   markPresent() {
//     console.log("Employee " + this.name + " is Present");
//   }
// }

// class Developer extends Employee {
//   submitCode() {
//     console.log("Code Submitted by " + this.name + " from " + this.dept);
//   }
// }

// class Intern extends Developer {
//   getInterData() {
//     console.log(
//       "Intern " + this.name + " work report is Ready from " + this.dept,
//     );
//   }
// }

// class Sales extends Employee {
//   getSales() {
//     console.log(
//       "Sales Class is extend by Emplyee " + this.name + " from " + this.dept,
//     );
//   }
// }

// const empObj = new Employee("Indra");
// empObj.markPresent();

// const devObj = new Developer("Indra", "Tech");
// const sales = new Sales("Reddy", "Tech");
// devObj.submitCode();
// devObj.markPresent();
// sales.getSales();
// sales.markPresent();

// const intern = new Intern("Ramco", "Crop R & D");
// intern.markPresent()
// intern.submitCode()
// intern.getInterData()

// SUPER KEY WORD

class Employee {
  constructor(name, dept) {
    this.name = name;
    this.dept = dept;
  }

  markPresent() {
    console.log("Employee " + this.name + " is Present");
  }

  getRole() {
    return "Employee of Office";
  }
}

class Developer extends Employee {
  constructor(name, dept, prefLang) {
    super(name, dept);
    this.preferedLanguage = prefLang;
  }

  getRole() {
    return super.getRole() + " Works with lang " + this.preferedLanguage;
  }

  submitCode() {
    console.log("Code Submitted by " + this.name + " from " + this.dept);
  }
}

const dev = new Developer("Indra", "Tech", "JS");

dev.markPresent();
dev.submitCode();
console.log(dev.getRole());
