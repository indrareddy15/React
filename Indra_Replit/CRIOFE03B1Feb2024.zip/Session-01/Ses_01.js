// 5th Feb 2024 CRIO_FE-03_B1_Session-01

const data = [
  {
    id: "8549673097",
    name: "Perthby",
    costPerHead: 4211,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/258045/pexels-photo-258045.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 8,
    category: "Hillside",
  },
  {
    id: "0610512104",
    name: "Nesbridge",
    costPerHead: 902,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2437297/pexels-photo-2437297.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 4,
    category: "Party",
  },
  {
    id: "7536826557",
    name: "Kenntic End",
    costPerHead: 2879,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/1433052/pexels-photo-1433052.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 11,
    category: "Hillside",
  },
  {
    id: "0733501601",
    name: "Pressal Creek",
    costPerHead: 1593,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2583852/pexels-photo-2583852.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 5,
    category: "Hillside",
  },
  {
    id: "0606744025",
    name: "Heathber",
    costPerHead: 803,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2132075/pexels-photo-2132075.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 4,
    category: "Cycling",
  },
  {
    id: "2621544733",
    name: "St Plympside",
    costPerHead: 3002,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/3116421/pexels-photo-3116421.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 9,
    category: "Party",
  },
  {
    id: "0534597016",
    name: "Lowtra",
    costPerHead: 4731,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/1525041/pexels-photo-1525041.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 20,
    category: "Cycling",
  },
  {
    id: "7247489857",
    name: "Chettbou Aux Dersting",
    costPerHead: 1354,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2175952/pexels-photo-2175952.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 9,
    category: "Cycling",
  },
  {
    id: "6710850298",
    name: "Bucktim",
    costPerHead: 2342,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2835562/pexels-photo-2835562.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 19,
    category: "Beaches",
  },
  {
    id: "9312138770",
    name: "Ntibran Lake",
    costPerHead: 3902,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/3783385/pexels-photo-3783385.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 12,
    category: "Cycling",
  },
  {
    id: "5915383379",
    name: "Warflin",
    costPerHead: 969,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/1662770/pexels-photo-1662770.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 15,
    category: "Hillside",
  },
];

// console.log("filtering", data);

// by using for loop
function filterByDuration() {
  const filteredArr = [];
  for (let i = 0; i < data.length; i++) {
    const adventure = data[i];
    if (adventure.duration > 8) {
      filteredArr.push(adventure);
    }
  }
  // console.log("Data", filteredArr);
}

filterByDuration();

// by using filter method
const filterAdv = data.filter((adv) => adv.duration > 8);
// console.log(filterAdv);

// by using map method
const filterData = data.map((item) => item.duration > 8);
// console.log(filterData);

// filter by Category
function filterByCategory() {
  let category = "Hillside";
  const filterAdvCat = data.filter((adv) => adv.category === category);
  // console.log(filterAdvCat);
}
filterByCategory();

const filterAdvCat = data.filter((adv) => adv.category === "Hillside");
// console.log(filterAdvCat);

function filterByCategory() {
  let categories = ["Hillside"];
  const flterAdvCate = data.filter((adv) => categories.includes(adv.category));
  // console.log(flterAdvCate);
}
filterByCategory();

// 1. When duration is available and but category is not avaialble
// filterByDuration() call method
// 2. When duration is not available and category is available
// filterByCategory() call method
// 3. When duration is available and category is available
// filterByDuration() && filterByCategory() call method
// 4. When duration is not available and category is not available
// console.log("No data found")

// Assuming you have an object named 'myObject' that you want to store
const myObject = {
  id: "0733501601",
  name: "Pressal Creek",
  costPerHead: 1593,
  currency: "INR",
  image:
    "https://images.pexels.com/photos/2583852/pexels-photo-2583852.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  duration: 5,
  category: "Hillside",
};

// // Convert the object to a string and store it in localStorage
// if (typeof localStorage !== "undefined") {
//   const storeData = localStorage.setItem("myObject", JSON.stringify(myObject));
//   console.log("storeData", storeData);
// }

// // Retrieve the object from localStorage and parse it back to an object
// if (typeof localStorage !== "undefined") {
//   const storedObject = JSON.parse(localStorage.getItem("myObject"));
//   // Now 'storedObject' contains the object retrieved from localStorage
//   console.log("storedObject", storedObject);
// }


