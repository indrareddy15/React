const obj = {
  "key": "value",
  "key1": "value1",
  "key2": "value2",
  "key3": "value3",
};

const keys = Object.keys(obj);
const values = Object.values(obj)
// console.log(Object.entries(obj))
// console.log(keys)
// console.log(values)
const x = new Object()
x.fname = "Indra"
x.lname = "Reddy"
console.log(x)