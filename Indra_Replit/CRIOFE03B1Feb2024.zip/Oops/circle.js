function Circle(radius, locationX, locationY) {
  this.radius = radius;
  this.location = {
    x: locationX,
    y: locationY,
  };

  this.draw = function () {
    console.log("Loaction: " + this.location.x + "," + this.location.y);
  };

  this.move = function (nextX, nextY) {
    this.location = {
      x: nextX,
      y: nextY,
    };
  };
}

let circleObj = new Circle(1, 0, 0);
for (let i = 1; i <= 10; i++) {
  circleObj.move(i, i);
  circleObj.draw();
}

//this keyword will points the object that excueting the current function