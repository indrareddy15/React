// function B() {}

const { log } = require("console");

// B.prototype.main = "Indra Reddy";

// console.log(B.prototype.main);

// function Car(_name, _color, _year) {
//   const name = _name;
//   const color = _color;
//   const year = _year;

//   return { name, color, year };
// }

// let obj = new Car("BMW", "Black", "2023");
// console.log(obj.name);
// console.log(obj.color);
// console.log(obj.year);
// console.log(obj);
// console.log(Car("BMW", "Black", "2023"));

// function Car(_name, _color, _year) {
//   this.name = _name;
//   this.color = _color;
//   this.year = _year;

//   this.start = function () {
//     console.log("Car is started");
//   };
// }

// let obj = new Car("BMW", "Black", "2023");
// console, log(obj);
var x = 2
function hello() {
  console.log(this.x);
}
hello()
