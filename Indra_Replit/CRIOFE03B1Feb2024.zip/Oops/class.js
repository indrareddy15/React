const employeeData = {
  John: 100,
  Pete: 300,
  Mary: 250,
};

class Util {
  constructor(employeeData) {
    this.eData = employeeData;
  }

  sumSalaries = () => {
    const salaries = Object.values(employeeData);
    console.log("salaries", salaries);
    const sum = salaries.reduce((a, b) => a + b, 0);
    console.log("sumSalaries", sum);
    return sum;
  };

  averageSalaries = () => {
    const totalSal = this.sumSalaries();
    const totalEmp = Object.keys(employeeData).length;
    const avgSalaries = totalSal / totalEmp;
    console.log("avgSalaries", avgSalaries);
    return avgSalaries;
  };

  findSalaryRange = () => {
    const salaries = Object.values(employeeData);
    const max = Math.max(...salaries);
    console.log("max", max);
    const min = Math.min(...salaries);
    console.log("min", min);
    const range = max - min;
    console.log("range", range);
    return range;
  };
}

const utilObj = new Util(employeeData);
const sum = utilObj.sumSalaries();
const avg = utilObj.averageSalaries();
const range = utilObj.findSalaryRange();
console.log("sum", sum);
console.log("avg", avg);
console.log("range", range);
