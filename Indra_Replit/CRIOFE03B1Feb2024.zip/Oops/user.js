function User(fullName) {
  this.fName = fullName;
  this.friendList = [];

  this.addFriend = function (fname) {
    this.friendList.push(fname);
  };

  this.printFriendList = function () {
    this.friendList.forEach((friend) => {
      console.log(this.fName + ":" + friend);
    });
  };

  this.mutalFriendList = function (userObj) {
    const mutlFrnd = userObj.friendList.filter((name) =>
      this.friendList.includes(name),
    );
    return mutlFrnd;
  };
}

const userObj1 = new User("Indra Reddy");
userObj1.addFriend("Ram");
userObj1.addFriend("venu");
userObj1.addFriend("Reddy");
userObj1.addFriend("Harish");
userObj1.addFriend("Evananda");

const userObj2 = new User("Soumya Reddy");
userObj2.addFriend("Supriya");
userObj2.addFriend("Navya");
userObj2.addFriend("Harish");
userObj2.addFriend("Evananda");
userObj2.addFriend("Archana");

const mF = userObj2.mutalFriendList(userObj1);
console.log(mF);

userObj1.printFriendList();
userObj2.printFriendList();

// console.log(userObj);
