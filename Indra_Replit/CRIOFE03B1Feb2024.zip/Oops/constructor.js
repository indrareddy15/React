let Person = function (name, gender, birthYear) {
  this.name = name;
  this.gender = gender;
  this.birthYear = birthYear;

  this.calcAge = function () {
    let age = new Date().getFullYear() - this.birthYear;
      console.log(age);
  };
};

let john = new Person("Jonh", "male", 1990);

// new key word
// 1. Create a new empty object ==> let john = {}
// 2. Set the prototype of john to Person.prototype  ==> this.john
// 3. Set the constructor of john to Person 
// john.name = "john"
// john.gender = "male"
// john.birthYear = 1990
// john.calcAge = function (){}


john.calcAge()
console.log(john)
