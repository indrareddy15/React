class Person {
  constructor(name, gender, birthYear) {
    this.name = name;
    this.gender = gender;
    this.birthYear = birthYear;
  }

  calcAge() {
    let age = new Date().getFullYear() - this.birthYear;
    console.log(age);
  }
}

let Indra = new Person("Indra", "male", 2000);
console.log(Indra);
Indra.calcAge();

let Reddy = new Person("Reddy", "male", 1998);
console.log(Reddy);
Reddy.calcAge();

let Ganta = new Person("Ganta", "male", 2002);
console.log(Ganta);
Ganta.calcAge();
