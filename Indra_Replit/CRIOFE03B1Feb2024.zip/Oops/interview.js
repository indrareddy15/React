const userDetails = {
  name: "John Doe",
  age: 14,
  verified: false
};

const copiedObj = {...userDetails}
console.log("copiedObj", copiedObj)

const assigObj = Object.assign({}, userDetails)
console.log("assigObj", assigObj)

const parse = JSON.parse(JSON.stringify(userDetails))
console.log("pasre", parse)