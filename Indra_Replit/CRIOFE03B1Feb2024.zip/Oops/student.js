// const student = {
//   fullName = "Indra Reddy";
//   greet: function () {
//     console.log("Hello, " + this.fullName);
//   }
// }

// function excuteObjectFunction(callback) {
//   callback();
// }

// excuteObjectFunction(student.greet)

// const timer = {
//   currentTime: 0,
//   showTime: function () {
//     console.log(this.currentTime);
//   },
//   addTen: function () {
//     this.currentTime += 10;
//     this.showTime();
//   },
// };

// setTimeout(timer.addTen.bind(timer), 1000);


function searchMatrix(matrix, target) {
  const m = matrix.length;
  const n = matrix[0].length;
  let left = 0;
  let right = m * n - 1;

  while (left <= right) {
      const mid = Math.floor((left + right) / 2);
      const row = Math.floor(mid / n);
      const col = mid % n;

      if (matrix[row][col] === target) {
          return true;
      } else if (matrix[row][col] < target) {
          left = mid + 1;
      } else {
          right = mid - 1;
      }
  }

  return false;
}

// Test cases
const matrix1 = [
  [1, 3, 5, 7],
  [10, 11, 16, 20],
  [23, 30, 34, 60]
];
console.log(searchMatrix(matrix1, 3)); // Output:
