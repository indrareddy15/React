// 7th Feb 2024 CRIO_FE-03_B1_Session-02

const advnData = [
  {
    id: "8549673097",
    name: "Perthby",
    costPerHead: 4211,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/258045/pexels-photo-258045.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 8,
    category: "Hillside",
  },
  {
    id: "0610512104",
    name: "Nesbridge",
    costPerHead: 902,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2437297/pexels-photo-2437297.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 4,
    category: "Party",
  },
  {
    id: "7536826557",
    name: "Kenntic End",
    costPerHead: 2879,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/1433052/pexels-photo-1433052.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 11,
    category: "Hillside",
  },
  {
    id: "0733501601",
    name: "Pressal Creek",
    costPerHead: 1593,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2583852/pexels-photo-2583852.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 5,
    category: "Hillside",
  },
  {
    id: "0606744025",
    name: "Heathber",
    costPerHead: 803,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2132075/pexels-photo-2132075.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 4,
    category: "Cycling",
  },
  {
    id: "2621544733",
    name: "St Plympside",
    costPerHead: 3002,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/3116421/pexels-photo-3116421.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 9,
    category: "Party",
  },
  {
    id: "0534597016",
    name: "Lowtra",
    costPerHead: 4731,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/1525041/pexels-photo-1525041.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 20,
    category: "Cycling",
  },
  {
    id: "7247489857",
    name: "Chettbou Aux Dersting",
    costPerHead: 1354,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2175952/pexels-photo-2175952.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 9,
    category: "Cycling",
  },
  {
    id: "6710850298",
    name: "Bucktim",
    costPerHead: 2342,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/2835562/pexels-photo-2835562.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 19,
    category: "Beaches",
  },
  {
    id: "9312138770",
    name: "Ntibran Lake",
    costPerHead: 3902,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/3783385/pexels-photo-3783385.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 12,
    category: "Cycling",
  },
  {
    id: "5915383379",
    name: "Warflin",
    costPerHead: 969,
    currency: "INR",
    image:
      "https://images.pexels.com/photos/1662770/pexels-photo-1662770.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    duration: 15,
    category: "Hillside",
  },
];

const filter = {
  duration: "2-6",
  category: ["Hillside, Party, Cycling"],
};

function filterByDuration(advnData, lowDur, highDur) {
  const filterDuration = advnData.filter(
    (itemAdv) => itemAdv.duration >= lowDur && itemAdv.duration <= highDur,
  );
  return filterDuration;
}

function filterByCategory(advnData, category) {
  const filterCategory = advnData.filter((itemAdv) =>
    category?.includes(itemAdv.category),
  );
  return filterCategory;
}

// const filteredCategory = filterByCategory(advnData, "Hillside");
// console.log("filteredCategory", filteredCategory);

function filterFunction(advnData, filter) {
  const splitDuration = filter.duration.split("-");
  const lowDur = splitDuration[0];
  const highDur = splitDuration[1];
  // console.log("splitDuration", splitDuration);

  let filteredDuration = filterByDuration(advnData, lowDur, highDur);
  let filteredCategory = filterByCategory(advnData, filter.category);
  console.log("filteredDuration", filteredDuration);
  console.log("filteredCategory", filteredCategory);

  // if (filter.duration.length > 0 && filter.category.length > 0) {
  //   console.log('// case1 : duration is selected and category is also selected')
  //   let filteredAdvn = filterByDuration(advnData, lowDur, highDur);
  //   filteredAdvn = filterByCategory(advnData, filter.category);
  //   return filteredAdvn;
  // }

  // if (filter.duration.length > 0 && filter.category.length === 0) {
  //   console.log("// case2: duration is selected but category is not selected")
  //   let filteredAdvn = filterByDuration(advnData, lowDur, highDur);
  //   return filteredAdvn;
  // }

  // if (filter.duration.length === 0 && filter.category.length > 0) {
  //   console.log("// case3: duration is not selected but category is selected")
  //   let filteredAdvn = filterByCategory(advnData, filter.category);
  //   return filteredAdvn;
  // }

  // return advnData;
}

const filteredFunction = filterFunction(advnData, filter);
// console.log("filteredFunction", filteredFunction);

function setFilterLocalStorage(filter) {
  localStorage.setItem("setItem", JSON.stringify(filter));
}

setFilterLocalStorage(filter);

function getFilterLocalStorage(filter) {
  return localStorage.getItem("setItem", JSON.parse(filter));
}

function selectDuration(e) {
  conlole.log(e.target.value);
}

function selectCategory(e) {
  console.log(e.target.value);
}


document.getElementById('duration-select').value = filters.duration;

// Generating Category Pills
const categoryListContainer = document.getElementById('category-list');
categoryListContainer.innerHTML = "";
filters.category.forEach(category => {
  const pill = document.createElement('div');
  pill.classList.add('badge', 'bg-secondary', 'me-2');
pill.setAttribute("style", "margin-right: 8px; border: 2px solid red")
  pill.textContent = category;
  categoryListContainer.appendChild(pill);
});



// Setting value for duration select element
var durationSelect = document.getElementById('duration-select');
durationSelect.value = filters.duration;

// Generating Category Pills
var categoryListContainer = document.getElementById('category-list');
categoryListContainer.innerHTML = "";

filters.category.forEach(function(category) {
    var pill = document.createElement('div');
    pill.classList.add('badge', 'bg-secondary', 'me-2');
    pill.textContent = category;
    categoryListContainer.appendChild(pill);
});




function generateFilterPillsAndUpdateDom(filter) {
  const categoryList = filter.category;
  const parentEl = document.getElementById('pills');
  categoryList.map((category) => {
    const element = document.createElement('span');
    element.classList.add('pill')
    element.setAttribute("style", "margin-right: 8px; border: 2px solid red")
    element.textContent = category;
    // parentEl.innerHTML = element;
    parentEl.append([element ,elementA]);
    // .appendChild(element);
  })
}