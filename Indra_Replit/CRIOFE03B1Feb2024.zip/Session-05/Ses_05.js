// 14th Feb 2024 CRIO_FE-03_B1_Session-05

conditionalRendering() {
  const divOne = document.getElementById("#one");
  const divTwo = document.getElementById("#two");

  if (flag) {
    divOne.style.display = "block";
    divTwo.style.display = "none";
  } else {
    divOne.style.display = "none";
    divTwo.style.display = "block";
  }
}

function toggle() {
  flag = !flag;
  console.log(fla);
}

let price = 100;

function inputChange(event) {
  const inputValue = Number(event.target.value);
  console.log(typeof inputValue);
  const targetEle = document.getElementById("total_cost");
  targetEle.innerText = inputValue * price;
}


const myForm = document.getElementById("myForm");

myForm.addEventListener("submit", (event) => {
  event.preventDefault(); //prevents default behavour of submit button
  console.log("Form submitted");

  const name = myForm.elements['name'].value
  const date = myForm.elements['date'].value
  const persons = myForm.elements['persons'].value

  console.log(name,date,persons)

  const req = fetch('URL', {
    method: "POST",
    body: JSON.stringify({
      name: name1,
      date: date1,
      persons: persons1
    }),
    headers: {
      'ContentType': 'application/json';
    }
  })
});
