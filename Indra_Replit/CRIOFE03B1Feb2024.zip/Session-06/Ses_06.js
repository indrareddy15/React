// 16th Feb 2024 CRIO_FE-03_B1_Session-06

// class A { //java is class bases language
//   public static void main(String[] args) {
//     System.out.println("Hello World");
//   }
// }

// JS is prototype based language
// function A() {
//console.log("Hello World");
//let a= 2
// }
// A.prototype.main = "Indra Reddy"
// console.log(A.prototype.main);

// A.prototype.main = () => {
//   console.log("Hello World");
// }
// function AnyFunc(name,Age) {
// }

// function Car(_name,_model,_color) {
//   const name = _name;
//   const model = _model;
//   const color = _color;

//   return {
//     name, model,color
//   }
// }
// let obj = Car("ABC","red",2024)
// console.log(obj.name)
// console.log(obj.model)
// console.log(obj.color)

// function Car(_name, _model, _color) {
//   // attributes or properties
//   this.name = _name;
//   this.model = _model;
//   this.color = _color;

//   //method
//   this.start = function () {
//     console.log("Car is started");
//   };
// }

// let obj = Car("ABC", "Blue", 2023);
// obj is called instance of the Object/Class "Car"
// console.log(obj);

// function Circle(_radius, _locationX, _locationY) {
//   // construntor function
//   // blue print for creatin Object
//   this.radius = _radius;
//   this.location = {
//     x: _locationX,
//     y: _locationY,
//   };

//   this.draw = function () {
//     console.log("LocationX" + this.location.x);
//     console.log("LocationY" + this.location.y);
//   };

//   this.move = function (nextX, nextY) {
//     this.location = {
//       x: nextX
//       y: nextY
//     }
//   }
// }

// let data = Circle(2,1,1);
// console.log(data)

// function Car(_name, _model, _color) {
//   // attributes or properties
//   this.name = _name;
//   this.model = _model;
//   this.color = _color;

//   //method
//   this.start = function () {
//     console.log("Car is started");
//   };
// }

// let obj = new Car("ABC", "Blue", 2023);
// let obj1 = new Car("Reddy", "Red", 2024);
// // obj is called instance of the Object/Class "Car"
// // console.log(obj);
// console.log(obj1.name)
// console.log(obj.name)
// console.log(obj.model)

// function Circle(raduis, locationX, locationY) {
//   this.radius = raduis;
//   this.location = {
//     x: locationX,
//     y: locationY,
//   };

//   this.draw = function () {
//     console.log("Loaction: " + this.location.x + "," + this.location.y);
//   };

//   this.move = function (nextX, nextY) {
//     this.location = {
//       x: nextX,
//       y: nextY,
//     };
//   };
// }

// const newObj = new Circle(1, 0, 0);
// for(let i = 1 ; i <= 10; i++) {
//   newObj.move(i, i);
//   newObj.draw();
// }
//   console.log(newObj);

// this keyword will point the object that is
// excueting the current function
// object is objA
// fn is printName

// const ObjA = {
//   name: "abc",
//   printName: function() {
//   console.log('Name is ' + this.name)
//   }
// }
// ObjA.printName()

// function User(fullname) {
//   this.fullName = fullname;
//   this.friendList = [];

//   this.addFriend = function (fName) {
//     this.friendList.push(fName);
//   };

//   this.printFriendList = function () {
//     this.friendList.forEach((friend) => {
//       console.log(this.fullName + ":" + friend);
//     });
//   };

//   this.mutulalFriendList = function (userObj) {
//     const mutalFriend = userObj.friendList.filter((name) =>
//       this.friendList.includes(name),
//     );
//     return mutalFriend;
//   };
// }

// const user1 = new User("Indra");
// user1.addFriend("Reddy");
// user1.addFriend("Ramco");
// user1.addFriend("Tech");

// const user2 = new User("Rama");
// user2.addFriend("React");
// user2.addFriend("Ramco");
// user2.addFriend("Tech");

// const mutualFriends = user1.mutulalFriendList(user2);
// console.log(mutualFriends);

// user1.printFriendList();
// user2.printFriendList();


// function Person(firstName, lastName, age) {
//   this.firstName = firstName;
//   this.lastName = lastName;
//   this.age = age;
// }
// const mike = new Person("mike", "grand", 23);
// const bob = Person("bob", "grand", 23);

// console.log(mike.firstName);
// console.log(bob.firstName);


// this keyword refer to the object that
// excueting current function

// fun ==> greet
// object ==> student

//Defining an object
// const student = {
//   fullName: "Rohit",
//   greet: function () {
//     //We want to print "Hello, Rohit"
//     console.log("Hello, " + this.fullName);
//     // console.log("Hello, " + this.greet);
//   },
// };

// //We define an executor function
// function executeObjectFunction(callback) {
//   callback();
// }

// //Passing the object method as callback
// executeObjectFunction(student.greet.bind(student));

// const student = {
//   name: "Indra",
//   greet:function() {
//     console.log(this)
//     console.log(this.name)
//   }
// }

// console.log(student.greet())

// function abc() {
//   console.log(this); // widow object
// }

// abc();

// const timer = {
//   currentTime: 0,
//   showTime: function () {
//     console.log(this.currentTime);
//   },
//   addTen: function () {
//     this.currentTime += 10;
//     this.showTime();
//   },
// };

// setTimeout(timer.addTen.bind(timer), 1000);

// function Person(_name, _age, _gender) {
//   this.name = _name;
//   this.age = _age;
//   this.gender = _gender;

//   this.print = function () {
//     console.log("Hello, ")
//   };
// }

// class Person {
//   constructor(_name, _age, _gender) {
//     this.name = _name;
//     this.age = _age;
//     this.gender = _gender;
//   }

//   print = () => {
//     console.log("Hello, Class");
//   };
// }

// const newObje = new Person("Aabc", 25, "Male");
// console.log(newObje.print());
