// function Car(name,model,year) {
//   const nm = name;
//   const md = model;
//   const yr = year;

//   return {
//     nm,md,yr
//   }
// }

// let car = Car("BMW","X5",2023)
// console.log(car)
// console.log(car.nm)

// const person = {
//  name: "Alok Raj",
//  address: {
//    city: "Bangalore",
//    country: "India"
//  },
//  printFullName: function () {
//   // console.log("Alok Raj");
//  },
//  interests: ["Product Development", "Cinematography", "Mentoring"]
// }
// console.log(person.name); //Alok Raj
// console.log(person.printFullName()); //undefined
// console.log(person.address.city); //Bangalore
// console.log(person.address.country); //India
// console.log(person.interests[0]); //Product Development

// function Bus(name, model, year) {
//   this.name = name;
//   this.model = model;
//   this.year = year;

//   this.start = function () {
//     console.log("This is a function");
//   };
// }

// let bus = new Bus("BMW","X5",2023)
// // let bus = Bus("BMW", "X5", 2023);

// console.log(bus.start);

// function Circle(radius, locationX, locationY) {
//   this.radius = radius;
//   this.location = {
//     x: locationX,
//     y: locationY,
//   };

//   this.draw = function () {
//     console.log("Location" + this.location.x + " " + this.location.y);
//   };

//   this.move = function (nextX, nextY) {
//     this.location.x = nextX;
//     this.location.y = nextY;
//   };
// }

// const circle1 = new Circle(1, 0, 0);
// for (let i = 0; i < 10; i++) {
//   circle1.move(i, i);
//   circle1.draw();
// }
// console.log(circle1);

// this keyword refer to the object that excueting the current function

// const person = {
//   name: "Indra",
//   greet: function () {
//     console.log(this);
//   },
// };

// const pr = person.greet();
// console.log(pr);

// function hello() {
//   console.log(this);
// }

// hello();

// function User(fullName) {
//   this.fName = fullName;
//   this.friendList = []

//   this.addFriend = function(friendName) {
//    console.log(this.friendList.push(friendName))
//   }
// }

  /**
 * @param {string} name
 * @param {number} age
 * @param {string} college
 * @param {string} city
 * @param {string} country
 * @return {object}
 */

// function methodOnObject(name, age, college, city, country) {
//   let person = {
//     name: name,
//     age: age,
//     college: college,
//     city: city,
//     country: country,
//     getCity: function () { return person.name + " lives in " + person.city + "."; }
//   };
//   return person;
//   // CRIO_SOLUTION_END_MODULE_ES6_FOUNDATIONS
// }


// async function getApiData() {
//   const rawres = await fetch("https://api.github.com/users/indrareddy15")
//   const response = await rawres.json()
//   console.log(response)
//   // console.log(Object.keys(response).length)
// }
// getApiData()

// console.log(myVar)
// var myVar = "Indra"

console.log(myLet)
let myLet = "Indra Reddy"