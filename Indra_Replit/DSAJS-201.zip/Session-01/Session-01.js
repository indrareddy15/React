// Intro to Stack and Queue

console.log("Intro to Stack and Queue");

// Stack is LastInFirstOut ==> LIFO
// Stack Operation:
// push(Adds an element to the top of the stack) Adds an item to the stack. If the stack is full, then it is said to be an Overflow condition.,
// pop(Removes the topmost element from the stack)
// top(Displays(return) the topmost element of the stack),
// peek(Returns the top element of the stack),
// isEmpty(Checks whether the stack is empty),
// isFull(Checks whether the stack is full),

// Time complexity is O(N^2)

// Find real world example of stack in goggle
// real world examples are undo and redo , function stack , backtracking , call stack , browser history , call stack , stack of plates , stack of books , stack of plates

// Searching value in the middle of stack is not possible we need to remove the top elemets and then we can check if the value is there not if not stack will become empty

// sorting in stack
// STEPS
// Remove from stack1
// check with the top of stack2
// if X >= to add to s2
// if X < top remove
// in JavaScript and Python we don't have stack avaliable we use array in place of stack

// Queue is FirstInFirstOut ==> FIFO

// brute force
// function nextLargestElement(n, arr) {
//   let ans = [];
//   for (let i = 0; i < arr.length; i++) {
//     nextLargest = -1;
//     for (let j = i + 1; j < arr.length; j++) {
//       if (arr[j] > arr[i]) {
//         nextLargest = arr[j];
//         break;
//       }
//     }
//     ans.push(nextLargest);
//   }
//   return ans;
// }
// console.log(nextLargestElement([10, 20, 30, 4, 5]));

function nextLargestElement(n, arr) {
  // create a stack array
  let stack = [];

  // create a ans array
  let ans = [];

  // run a loop from right to left
  for (let i = n - 1; i >= 0; i--) {
    //remove all the smaller numbers
    // check if the top element is smaller than arr[i]
    // peek the top element stack[stack.length-1]
    while (stack.length > 0 && stack[stack.length - 1] <= arr[i]) {
      // remove the top element from stack
      stack.pop();
    }

    //check if there is any element in stack
    if (stack.length > 0) {
      //peek the top element
      ans[i] = stack[stack.length - 1];
    } else {
      ans[i] = -1; // if there is no bigger element, then -1
    }
    stack.push(arr[i]);
  }
  return ans;
}
console.log("nextLargestElement: -", nextLargestElement(4, [1, 3, 2, 4]));
// Time complexity is O(N) Linear

// Types of Stacks
// Fixed Size Stack: As the name suggests, a fixed size stack has a fixed size and cannot grow or shrink dynamically
//Dynamic Size Stack : A dynamic size stack can grow or shrink dynamically his type of stack is implemented using a linked list

//=======================================================//

// Queue
// Queue is FirstInFirstOut ==> FIFO
// real life example is printer queue , ticket queue , ticket booking system , notifcation queue, CPU scheduling,
// add / push / enqueue => add an element at end
// remove / poll / dequeue / ==> remove an element from start
// peek
// size

// some issue with reguler queue check the slides
// Time complexity is O(N) Linear
// types of queue are
//circular queue ,
// double ended queue ,
//priority queue , it works based on prority


function postFixExpression(exp) {
  let stack = []

  let arr = exp.split(' ')
  for(let str of arr) {
    if( str === '+') {
      let b = stack.pop()
      let a = stack.pop()
      stack.push(a+b)
    } else if(str === '-') {
      let b = stack.pop()
      let a = stack.pop()
      stack.push(a-b)
    } else if(str === '*') {
      let b = stack.pop()
      let a = stack.pop()
      stack.push(a*b)
    } else {
      stack.push(Number(str))
    }
  }
  return stack.join(' ');
}

console.log(postFixExpression('2 3 +'))

