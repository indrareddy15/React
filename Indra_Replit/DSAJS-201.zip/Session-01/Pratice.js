class Stack {
  constructor() {
    this.items = [];
  }
    push(element) {
      this.items.push(element);
  }
  pop() {
    if (this.items.length == 0) {
      return "Underflow";
    } else {
      return this.items.pop();
    }
  }
  peek() {
    return this.items[this.items.length - 1];
  }
  isEmpty() {
    return this.items.length == 0;
  }
  printStack() {
    var str = "";
    for (var i = 0; i < this.items.length; i++) {
      str += this.items[i] + " ";
    }
    return str;
  }
}
// let stack = new Stack();
// stack.push(1);
// stack.push(2);
// stack.push(3);
// stack.push(4);
// console.log(stack.isEmpty());

class NewStack {
  constructor() {
    this.stack = [];
  }

  push(ele) {
    this.stack.push(ele);
  }

  pop() {
    if (this.isEmpty()) {
      return "Stack is empty can't Perform POP Operation";
    } else {
      return this.stack.pop();
    }
  }

  peek() {
    if (this.isEmpty) {
      return "Stack is empty can't Perform Peek Operation";
    } else {
      this.stack[stack.length - 1];
    }
  }

  isEmpty() {
    return this.size() === 0;
  }

  size() {
    return this.stack.length;
  }

  printStack() {
    let str = "";
    for (let i = 0; i < this.size(); i++) {
      str += this.stack[i] + " ";
    }
    return str;
  }
}

let stack = new NewStack();
stack.push(10);
stack.push(20);
stack.push(30);
console.log(stack.printStack());
// console.log(stack.peek());
// console.log(stack.pop());
//console.log(stack);

// Given an Input string s , reverse the order of the words
// Input: "I am a good boy"  ----> output: "boy good a am I"

function reverseWords(str) {
  return str.split(" ").reverse().join(" ");
}
console.log(reverseWords("   I am a good boy"));

function newRvs(s) {
  let split = s.split(" ");
  // console, log("split", split);
  let stack = [];

  for (let i of split) {
    stack.push(i);
  }
  let final = "";
  while (stack.length) {
    let curr = stack.pop();

    if (curr) {
      final += " " + curr;
    }
  }
  return final.trim();
}

console.log(newRvs("I am a good boy"));
