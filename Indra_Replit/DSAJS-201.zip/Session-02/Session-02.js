// Session 2 is Problem Solving
// below problems are very good stack problems

// valid Paranthesis

function valParanthesis(str) {
  let stack = [];
  let map = {
    "(": ")",
    "{": "}",
    "[": "]",
  };

  for (let i = 0; i < str.length; i++) {
    if (str[i] === "(" || str[i] === "{" || str[i] === "[") {
      stack.push(str[i]);
    } else {
      let last = stack.pop();
      if (str[i] !== map[last]) {
        return false;
      }
    }
  }
  if (stack.length !== 0) {
    return false;
  }
  return true;
}

console.log(valParanthesis("()[]{(}"));

function validParenthesis(s) {
  let stack = [];
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "(" || s[i] === "[" || s[i] === "{") {
      stack.push("(");
      stack.push("[");
      stack.push("{");
    } else {
      // check weather stack is empty or not
      if (stack.length === 0) {
        return false;
      }
      stack.pop();
    }
  }
  return stack.length === 0 ? true : false;
}

// Time Complexity: O(N)
// Space Complexity: O(N)

function longestValidParenthesisSubstring(s) {
  let ans = 0;
  let stack = [];
  stack.push(-1);

  for (let i = 0; i < s.length; i++) {
    if (s[i] === "(") {
      stack.push(i);
    } else {
      stack.pop();

      if (stack.length === 0) {
        stack.push(i);
      } else {
        ans = Math.max(ans, i - stack[stack.length - 1]);
      }
    }
  }
  return ans;
}
console, log("Longest", longestValidParenthesisSubstring("()(()(())"));

// Time Complexity: O(N)
// Space Complexity: O(N)

// when ever you are working with substrings focus on indexs like start index and end index

// Hashing and Sliding Window concept return elements
function countDistinctElement(n, b, arr) {
  // create aempty map
  // for loop over the arr i = 0
  // add to map
  // if mas.has(arr[i])
  // incrment the value by 1
  // else
  // set the value to 1

  // check if i is greater than window size
  // if i >= b -1
  // ans.push(map.size)

  // remove the element from map
  // j = i = b + 1
  // if count == 1
  // map.delete(arr[j])

  let ans = [];
  let map = new Map();

  for (let i = 0; i < n; i++) {
    if (map.has(arr[i])) {
      map.set(arr[i], map.get(arr[i]) + 1);
    } else {
      map.set(arr[i], 1);
    }

    if (i >= b - 1) {
      ans.push(map.size);

      let lastEle = arr[i - b + 1];
      let lastEleCount = map.get(lastEle);
      if (lastEleCount === 1) {
        map.delete(lastEle);
      } else {
        map.set(lastEle, lastEleCount - 1);
      }
    }
  }
  return ans;
}
console.log(
  "countDistinctElement",
  countDistinctElement(6, 3, [1, 2, 1, 3, 4, 3]),
);

// function anagram(str1, str2) {
//   let n1 = str1.split("").length;
//   let n2 = str2.split("").length;
//   if (n1 !== n2) {
//     return false;
//   }

//   str1.sort((a, b) => a - b);
//   str2.sort((a, b) => a - b);

//   for (let i = 0; i < n1; i++) {
//     if (str1[i] !== str2[i]) {
//       return false;
//     }
//   }

//   return true;
// }
// console.log(anagram("bac", "bca"));

function firstUniqueNumber(n, arr) {
  let map = new Map();
  for (let i = 0; i < n; i++) {
    if (map.has(arr[i])) {
      map.set(arr[i], map.get(arr[i]) + 1);
    } else {
      map.set(arr[i], 1);
    }
  }

  for (let [key, value] of map.entries()) {
    if (value === 1) {
      return key;
    }
  }
  return -1;
}

console.log("firstUniqueNumber", firstUniqueNumber(4, [9, 6, 7, 6]));

class Node {
  constructor(val, min, next) {
    this.val = val;
    this.min = min;
    this.next = next;
  }
}

class MinStack {
  constructor() {
    this.head = null;
  }

  push(x) {
    this.head = !this.head
      ? new Node(x, x, null)
      : new Node(x, Math.min(val, this.head.min), this.head);
  }

  pop() {
    this.head = this.head.next;
  }

  top() {
    return this.head.val;
  }

  getMin() {
    return this.head.min;
  }
}

function partition(head, X) {
  let lessHead = new ListNode(0);
  let equalHead = new ListNode(0);
  let greaterHead = new ListNode(0);

  let less = lessHead;
  let equal = equalHead;
  let greater = greaterHead;

  let current = head;

  while (current) {
    if (current.val < X) {
      less.next = current;
      less = less.next;
    } else if (current.val === X) {
      equal.next = current;
      equal = equal.next;
    } else {
      greater.next = current;
      greater = greater.next;
    }
    current = current.next;
  }

  greater.next = null;

  less.next = equalHead.next;
  equal.next = greaterHead.next;

  // Helper function to print the linked list
  function printLinkedList(head) {
    let result = [];
    let current = head;
    while (current) {
      result.push(current.val);
      current = current.next;
    }
    return result.join(" ");
  }

  printLinkedList(lessHead.next);

  return lessHead.next;
}

class LinkedList {
  constructor() {
    let dummyNode = new ListNode(-1);
    this.head = dummyNode;
    this.tail = dummyNode;
  }

  addNode(node) {
    this.tail.next = node;
    this.tail = node;
  }
}

function xyz(head, x) {
  let lessHead = new ListNode(0);
  let equalHead = new ListNode(0);
  let greaterHead = new ListNode(0);

  let current = head;

  while (current !== null) {
    if (current.val < x) {
      lessHead = addNode(current)
    } else if (current.val === x) {
      equalHead = addNode(current)
    } else {
      greaterHead = addNode(current)
    }
    current = current.next;
  }

  greaterHead.tail.next = null;
  equalHead.tail.next = greaterHead.head.next;
  lessHead.tail.next = equalHead.head.next;

  return lessHead.next;
}


// lessLL.addNode(current)
// curr = curr.next


// gll.t.ne = null;
// q.t.n = g.ll.head.next
// lessLL.tail.next = equalLL.head.next


// return lessLL.head.next