// Applications of LinkedList are Stack and Queue for example Image Viewer

class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
    this.size = 0; // to check the size of the linked list
    // when add a node +1 and remove node -1
  }

  isEmpty() {
    return this.size === 0;
  }

  getSize() {
    return this.size;
  }

  // Add a Element to Start of LinkedList Node
  addEleStrtNode(value) { // TC is O(1) constrant
    // Prepend
    let newNode = new Node(value);

    if (this.isEmpty()) {
      this.head = newNode;
    } else {
      newNode.next = this.head;
      this.head = newNode;
    }

    this.size++;
  }

  // Add a Element to End of LinkedList Node
  addEleEndNode(value) { // TC is O(N) Linear
    let newNode = new Node(value);

    if(this.isEmpty()) {
      this.head === newNode;
    } else {
      let prev = this.head
      while(prev.next !== null) {
        prev = prev.next;
      }
      prev.next = newNode;
    }
    this.size++
  }

  // Add a Element to a specific index of LinkedList Node
  insertAtIndex(value, index){
    if(index < 0 || index > this.size) {
      return;
    }
    if(index === 0) {
      this.addEleStrtNode(value);
    } else {
      let newNode = new Node(value);
      let prev = this.head;
      for(let i = 0; i < index - 1; i++) {
        prev = prev.next;
      }
      newNode.next = prev.next;
      prev.next = newNode;
      this.size++
    }
  }

  // 
  printLinkedList() {
    if (this.isEmpty()) {
      console.log("List is empty");
    } else {
      let curr = this.head;
      let listValue = ''
      while (curr !== null) {
        listValue += `${curr.value} `
        // console.log(curr.value);
        curr = curr.next;
      }
      console.log("List value is", listValue)
    }
  }
}

let ll = new LinkedList();
// console.log(ll.isEmpty());
// console.log(ll.getSize());
// ll.printLinkedList();
ll.addEleStrtNode(23);
ll.addEleStrtNode(5);
ll.addEleStrtNode(42);
ll.addEleStrtNode(150);

console.log("if it's Empty", ll.isEmpty());
console.log("Size", ll.getSize());
// ll.printLinkedList();
// ll.addEleEndNode(100);
// ll.addEleEndNode(200);
// ll.printLinkedList();

// ll.insertAtIndex(1000, 0);
// ll.insertAtIndex(2000, 2);
ll.printLinkedList();
