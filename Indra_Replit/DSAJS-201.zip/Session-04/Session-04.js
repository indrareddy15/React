// Linked List
// console.log("Linked List");
// How to create a Node
// we will work on OOPs in JavaScript by using classes

// const { cursorTo } = require("readline");

// // class tells us how to create a node

class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

// let node1 = new Node(23);
// let node2 = new Node(5);
// let node3 = new Node(42);
// let node4 = new Node(4);
// let node5 = new Node(20);
// let node6 = new Node(67);

// node1.next = node2;
// node2.next = node3;
// node3.next = node4;
// node4.next = node5;
// node5.next = node6;

// console.log(node1);
// console.log(node2);
// console.log(node3);

// function printLL(head) {
//   // console.log(head.value)
//   // While loop is similary to for loop(in arrays)
//   let cur = head;
//   while (cur.next !== null) {
//     console.log(cur.value);
//     cur = cur.next;
//   }

//   console.log("LastNode is", cur.value);
//   cur.value = new Node();
// }

// printLL(node1);

class Linked {
  constructor() {
    this.head = null;
  }

  addNodeToEnd(value) {
    //  Write how to add a node to the end of the linked list
    //  1. Create a new node
    //  2. Check if the linked list is empty
    //  3. If the linked list is empty then set the head to the new node
    //  4. If the linked list is not empty then traverse to the last node
    //  5. Set the next of the last node to the new node
    //  6. Set the next of the new node to null
    //  7. Return the linked list
    let newNode = new Node(value);
    if (this.head === null) {
      // append first node
      this.head = newNode;
    } else {
      // append remaning nodes
      let cur = this.head;
      while (cur.next !== null) {
        // find the last Node to append newNode
        console.log(cur.value);
        cur = cur.next;
      }
      // curr is the last node
      cur.next = newNode;
    }
    return this;
  }
}

let ll = new Linked();
ll.addNodeToEnd(23);
ll.addNodeToEnd(5);
ll.addNodeToEnd(42);
ll.addNodeToEnd(4);
ll.addNodeToEnd(20);
ll.addNodeToEnd(67);

// class LinkedList {
//   constructor() {
//    this.head = null;
//   }

//   addNodeToEnd(value) {
//     let newNode = new Node(value);
//     let cur = this.head
//     while(cur.next !== null) {
//       console.log(cur.value)
//       cur = cur.next;
//     }
//     cur.next = newNode;
//   }

// }

// Insertion

class NodeLL {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

// function reversedLinkedList(head) {
//   let prev = null;
//   let curr = head;
//   let next = null;

//   while (curr !== null) {
//     next = curr.next; // Save the next node, other wise it will be lost
//     curr.next = prev; // reverse the link from curr => next to cur to prev

//     //update pointer
//     prev = curr;
//     curr = next;
//   }
//   return prev; // prev is new head of reversed LL
// }

// console.log("reversedLinkedList", reversedLinkedList([1, 2, 3, 4, 5]));

// Time Complixity is O(N)
// Space Complexity is O(1)

// Fast and Slow Pointers
// one moves fast and other moves slow
// slow = slow.next  => jumps one time
// fast = fast.next.next ==> jumps two times

function moveMiddleToHead(head) {
  if (head === null || head.next === null) {
    return head;
  }

  // Find the middle node using slow and fast
  let prev = null;
  let slow = head;
  let fast = head;

  while (fast !== null && fast.next !== null) {
    prev = slow;
    slow = slow.next;
    fast = fast.next.next;
  }

  // remvove the middle node
  prev.next = slow.next;

  // update the slow with new head
  slow.next = head;
  head = slow;

  return head;
}

// Time complixity is O(N/2) => O(N)
// Space complixity is O(1)

// Partition of LinkedList
class LinkedList {
  constructor(value) {
    this.value = value
    this.next = null
  }
}
function partionLinkedList(head, x) {
  let lessLL = new LinkedList();
  let equalLL = new LinkedList();
  let greaterLL = new LinkedList();

  let cur = head;
  while (cur !== null){
    if(cur.value < x) {
      lessLL.addNodeToEnd(cur.value);
    } else if (cur.value === x) {
      equalLL.addNodeToEnd(cur.value);
    } else {
      greaterLL.addNodeToEnd(cur.value);
    }
    cur = cur.next;
  }
  return lessLL.head;
}

// Time complixity is O(N)
// Space complixity is O(1)
console.log("partionLinkedList", partionLinkedList([1, 2, 3, 4, 5], 3));
