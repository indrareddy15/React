class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
  }

  addNodeToEnd(value) {
    let newNode = new Node(value);

    if (this.head === null) {
      this.head = newNode;
    } else {
      let curr = this.head;
      while (curr.next !== null) {
        curr = curr.next;
      }
      curr.next = newNode;
    }
  }

  printLinkedList() {
    let curr = this.head;
    while (curr !== null) {
      console.log(curr.value);
      curr = curr.next;
    }
  }

  reverserLL(head) {
    let prev = null;
    let curr = head;
    let next = null;

    while (curr !== null) {}
  }
}

let ll = new LinkedList();
ll.addNodeToEnd(23);
ll.addNodeToEnd(5);
ll.addNodeToEnd(42);
ll.addNodeToEnd(4);
ll.addNodeToEnd(20);
ll.addNodeToEnd(67);

ll.printLinkedList();
