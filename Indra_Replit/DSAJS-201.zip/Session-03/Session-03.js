// Session-03

function findAllAnagramsInAString(s, p) {
  let pmap = new Map();

  for (let i = 0; i < p.length; i++) {
    pmap.set(p[i], (pmap.get(p[i]) || 0) + 1);
  }

  let ans = [];
  let smap = new Map();
  for (let i = 0; i < s.length; i++) {
    smap.set(s[i], (smap.get(s[i]) || 0) + 1);
    if (i >= p.length - 1) {
      if (isMapEqual(smap, pmap)) {
        let j = i - p.length + 1;
        ans.push(j);
      }

      let lastEle = s[i - p.length + 1];
      let lastEleCount = smap.get(lastEle);
      if (lastEleCount === 1) {
        smap.delete(lastEle);
      } else {
        smap.set(lastEle, lastEleCount - 1);
      }
    }
  }

  return ans;
}

function isMapEqual(map1, map2) {
  if (map1.size !== map2.size) {
    return false;
  }

  for (let [key, value] of map1) {
    if (map2.get(key) !== value) {
      return false;
    }
  }
  return true;
}
console.log("Anagram", findAllAnagramsInAString("aaba", "ab"));

function longestPalindrome(n, str) {
  let map = new Map();
  for (let i = 0; i < n; i++) {
    map.set(str[i], (map.get(str[i]) || 0) + 1);
  }

  let len = 0;
  let isOdd = false;
  for (let [key, value] of map.entries()) {
    if (value % 2 === 0) {
      len += value;
    } else {
      len += value - 1;
      isOdd = true;
    }
  }

  if (isOdd) {
    len += 1;
  }

  return len;
}
console.log("longestPalindrome", longestPalindrome(4, "bbde"));

function frequentWords(words, k) {
  let map = new Map();
  for (let i = 0; i < words.length; i++) {
    map.set(words[i], (map.get(words[i]) || 0) + 1);
  }

  let arr = Array.from(map.entries());

  arr.sort((a, b) => {
    if (a[1] == b[1]) {
      return a[0].localeCompare(b[0]);
    }
    return b[1] - a[1];
  });

  let anss = [];
  for (let i = 0; i < k; i++) {
    anss.push(arr[i][0]);
  }
  return anss;
}

console.log("freq", frequentWords(["car", "bus", "car"], 1));


function subarraysDivByK(arr, k) {
  
}

function postfixExpression(exp) {
  let stack = [];
  let arr = exp.split(' ');
  for(let str of arr){
    if(str === '+' || str === '-' || str === '*' || str === '/') {
      let b = stack.pop();
      let a = stack.pop();
      stack.push(eval(a + str + b));
    }
  }
  return stack;
}

console.log("postfixExpression", postfixExpression('2 3 +'));