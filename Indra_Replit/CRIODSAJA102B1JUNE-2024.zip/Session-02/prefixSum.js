// PrefixSum concept

// prefix sum = arr[0] + arr[1] + .... + arr[i - 1] + arr[i]  from the begging
// Suffix sum = arr[i] + arr[i + 1] + .... + arr[n - 1]   from the end

let arr = [1, 4, 6, 3, 2];

// Prefix Sum[2] = arr[0] + arr[1] + arr[2] = 1 + 4 + 6 = 11
// Suffix Sum[2] = arr[4] + arr[3] + arr[2] = 2 + 3 + 6 = 11

// Find the prefix sum value for all indices of agiven array
function prefixSum(arr, n) {
  let prefixSum = new Array(n);
  prefixSum[0] = arr[0];

  for (let i = 0; i < n; i++) {
    prefixSum[i] = prefixSum[i - 1] + arr[i];
  }
  return prefixSum;
}

// let prefixArr = [1, 4, 6, 3, 2]
// console.log(prefixSum(prefixArr));

function suffixSum(arr, n) {
  let suffixSum = new Array(n);
  suffixSum[n - 1] = arr[n - 1];

  for (let i = n - 2; i >= 0; i--) {
    suffixSum[i] = suffixSum[i + 1] + arr[i];
  }
  return suffixSum;
}

// let suffixArr = [1, 4, 6, 3, 2]
// console.log(suffixSum(suffixArr));

// (prefixSum[i - 1] + arr[i]) + suffxSum[i + 1] = sum of all elements(prefixSum[n - 1]);
// prefixSum[i] + suffixSum[i + 1] = prefixSum[n - 1] ==> {A + B = C}
// SuffixSum[i + 1] = prefixSum[n - 1] - prefixSum[i]] ==> {B = C - A}

function equalPartition(n, arr) {
  for (let i = 1; i < n; i++) {
    let lefSum = 0;
    for (let j = i - 1; j >= 0; j--) {
      lefSum += arr[j];
    }

    let rightSum = 0;
    for (let k = i + 1; k < n; k++) {
      rightSum += arr[k];
    }

    if (lefSum === rightSum) {
      return arr[i];
    }
  }
  return -1;
}

let arrData = equalPartition(4, [1, 4, 2, 5]);
console.log(arrData);

function equiPartition1(n, arr) {
  let prefixSum = new Array(n);

  prefixSum[0] = arr[0];
  for (let i = 1; i < n - 1; i++) {
    prefixSum[i] = prefixSum[i - 1] + arr[i];
  }

  // a - b - c ==> a - (b + c)
  for (let i = 1; i < n - 2; i++) {
    if (prefixSum[i - 1] === prefixSum[n - 1] - prefixSum[i]) {
      return arr[i];
    }
  }
  return -1;
}
let arrData1 = equalPartition(4, [1, 4, 2, 5]);
console.log(arrData1);

function contigousSubArray(n, arr) {
  let sum = 0;
  let max = -Infinity;

  for (let i = 0; i < n; i++) {
    sum = Math.max(sum + arr[i], arr[i]);

    max = Math.max(max, sum);
  }
  return max;
}

function subarraySumZeros(n, arr) {
  let prefixSet = new Set();
  let sum = 0;

  for (let i = 0; i < n; i++) {
    sum += arr[i];

    if (sum === 0 || prefixSet.has(sum)) {
      return "Yes";
    }
    prefixSet.add(sum);
  }
  return "No";
}

function minNoofMeetingRoom(meetings) {
  let resList = [];

  for (let meeting of meetings) {
    resList.push({ timeStamp: meeting[0], RoomChange: +1 });
    resList.push({ timeStamp: meeting[1], RoomChange: -1 });
  }
  resList.sort((a, b) => a.timeStamp - b.timeStamp);

  let minRoom = 0;

  let meetingRoom = 0;
  for (let meet of resList) {
    meetingRoom += meet.RoomChange;
    minRoom = Math.max(minRoom, meetingRoom);
  }
  return minRoom;
}


function logestSubString(s) {
  let hashMap = new Map();
  let left = 0;
  let answer = 0;

  for (let i = 0; i < s.length; i++) {
    let prev = hashMap.get(s[i]);

    if(prev !== undefined && prev >= left) {
      left = prev + 1;
    }
    hashMap.set(s[i], i);
    answer = Math.max(answer, i - left + 1);
  }
  return answer;    
}