// Two Pointer
// two pointer (two variables pointing to the start and end of the array{different indices})
// console.log("Two Pointer");
// Time Complexity of sorting is O(nlogn)

// Linear Approach
// function findTar(arr, Tar) {
//   for(let i =0; i < arr.length; i++) {
//     for(let j = 0 ; j < arr.length; j++) {
//       if(arr[i] + arr[j] == Tar) {
//         return [arr[i], arr[j]]
//       }
//     }
//   }
//   return false;
// }

//Time Comploxity is O(n^2))
//Space Comploxity is O(1)

// console.log(findTar([1,2,3,4,5,6,7,8,9], 15))

// Two Pointer Approach
function findTar2(arr, Tar) {
  let left = 0;
  let right = arr.length - 1;
  {
    while (left < right) {
      let currSum = arr[left] + arr[right];
      if (currSum === Tar) {
        return [arr[left], arr[right]];
      } else if (currSum >= Tar) {
        right--;
      } else {
        left++;
      }
    }
  }
  return -1;
}

// console.log(findTar2([4, 7, 9, 11, 13], 20));

function twoSum(nums, target) {
  let arr = [];
  for (let i = 0; i < nums.length; i++) {
    arr.push([num[i], i]);
  }
  arr.sort((a, b) => a[0] - b[0]);

  let left = 0;
  let right = arr.length - 1;

  while (left < right) {
    let currSum = arr[left][0] + arr[right][0];
    if (currSum === target) {
      return [arr[left][1], arr[right][1]].sort((a, b) => a - b);
    } else if (currSum >= target) {
      right--;
    } else {
      left++;
    }
  }
  return -1;
}

// merging two sorted arrays
function twoSortedArr(nums1, nums2) {
  let arr = [...nums1, ...nums2];
  return arr.sort((a, b) => a - b);
}

let arr1 = [10, 8, 3, 7, 9];
let arr2 = [2, 1, 6, 5, 4];
// console.log(twoSortedArr(arr1, arr2));

function mergeSorted(m, nums1, n, nums2) {
  let i1 = 0;
  let i2 = 0;
  let ans = [];

  while (i1 < m && i2 < n) {
    if (nums1[i1] < nums2[i2]) {
      ans.push(nums1[i1]);
      i1++;
    } else {
      ans.push(nums2[i2]);
      i2++;
    }
  }

  while (i1 < m) {
    ans.push(nums1[i1]);
    i1++;
  }

  while (i2 < n) {
    ans.push(nums2[i2]);
    i2++;
  }
  return ans;
}

let m = 3;
let n = 3;
let nums1 = [1, 2, 3];
let nums2 = [2, 5, 6];
// console.log("merge Sorted ", mergeSorted(m, nums1, n, nums2));

function getIthindex(nums, j) {
  let ans = 0;

  for (let i = 0; i < j; i++) {
    if (nums[i] < nums[j]) {
      ans = Math.max(ans, nums[i]);
    }
  }
  return ans;
}

function getKthindex(nums, j) {
  let ans = 0;

  for (let k = 0; k < nums.length - 1; k++) {
    if (nums[k] > nums[j]) {
      ans = Math.max(ans, nums[k]);
    }
  }
  return ans;
}

function maxSumTriplet(n, nums) {
  let ans = 0;

  for (let j = 0; j < n; j++) {
    let ithValue = getIthindex(nums, j);

    let kthValue = getKthindex(nums, j);

    if (nums[j] + ithValue + kthValue > ans && ithValue > 0 && kthValue > 0) {
      ans = Math.max(ans, nums[j] + ithValue + kthValue);
    }
  }
  return ans;
}

console.log(maxSumTriplet(5, [1, 2, 3, 4, 5]));

function removeDuplicates(nums, n) {
  let val = 0;
  let count = 0;
  let j = 0;

  for (let i = 0; i <= n - 1; ) {
    val = nums[i];
    count = 0;

    while (i < n && nums[i] == val) {
      count++;
      i++;
    }

    if (count > 2) {
      count = 2;
    }
    while (count-- > 0) {
      nums[j] = val;
      j++;
    }
  }
  return [j, nums];
}

function findMostWater(height) {
  let ans = 0;
  let left = 0;
  let right = height.length - 1;

  while (left < right) {
    let area = Math.min(height[left], height[right]) * (right - left);
    ans = Math.max(ans, area);

    if (height[left] < height[right]) {
      left++;
    } else {
      right--;
    } 
  }
  return ans;
}
