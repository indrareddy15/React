//Problem: Using var keyword print 1-100 and it print next number after a delay of 5 seconds So if you are printing 1 wait for 5 seconds and then print 2 again wait for 5 seconds and print 3 It should take total 45 seconds to print all the numbers

function findNum(num) {
  for(var i = 1 ; i <= num; i++) {
    console.log(num)
  }
}

console.log(findNum(10))

function printNumbersWithDelay() {
  for (var i = 1; i <= 100; i++) {
      (function(n) {
          setTimeout(function() {
              console.log(n);
          }, n * 5000); // 5 seconds delay for each number
      })(i);
  }
}

printNumbersWithDelay();

Find Pair with given sum in Sorted Array

function twoSumInSortedArray(n, arr, target_sum) {
    let left = 0;
    let right = n - 1;
    let cnt = 0;

    while (left < right) {
        let currSum = arr[left] + arr[right];
        if (currSum === target_sum) {
            cnt++;
            left++; // Increment left to continue searching
            right--; // Decrement right to continue searching
        } else if (currSum < target_sum) {
            left++;
        } else {
            right--;
        }
    }
    return;
}

function twoSumInSortedArray(n, arr, target_sum) {
    let left = 0;
    let right = n - 1;
    // let cnt = 0;

    while (left < right) {
        let currSum = arr[left] + arr[right];
        console.log(currSum);
        if (currSum === target_sum) {
            return "Present";
        } else if (currSum < target_sum) {
            left++;
        } else {
            right--;
        }
    }
    return "Not Present";
}

// console.log(twoSumInSortedArray(5, [49, 55, 61, 77 ,79],94))

// unsorted arre
function maxSumTriplet(n, arr) {}

//Find Triplet with maximum sum in unsorted array [pattren introduction]

let str = "Welcome to Csharp corner";
let newArr = []
let data = str.split(" ")
for(let i = 0 ; i < data.length; i++) {
    let newData = data[i].split("").reverse().join("")
    newArr.push(newData)
}
let finalData = newArr.join(" ")
console.log("Final Data", finalData)
// reverse().join("");
// console.log(data);

// function revrseString(str) {
//     for (let i = 0; i < str.length; i++) {
//         newArr.push(str[i]);
//     }
// }

//Write a program  to reverse each word in a given string?

function reverseWord(str) {
    let newArr = [];
    let data = str.split(" ");
    for (let i = 0; i < data.length; i++) {
        let newData = data[i].split("").reverse().join("");
        newArr.push(newData);
    }
    return newArr.join(" ");
}

//Write a program to remove duplicate characters from a string?

function removeDuplicate(str){
    let newArr = [];
    let data = str.split("");
    for(let i = 0 ; i<str.length; i++){
        if(!newArr.includes(data[i])){
            newArr.push(data[i])
        }
    }
    return newArr.join("");
}