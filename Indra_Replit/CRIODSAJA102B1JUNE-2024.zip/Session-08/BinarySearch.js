function binarySearch(arr, target) {
  let left = 0;
  let right = arr.length - 1;

  while (left <= right) {
    let mid = Math.floor((left + right) / 2);

    if (arr[mid] === target) {
      return mid;
    } else if (arr[mid] <= target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }
  return -1;
}

console.log(binarySearch([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 8));

// by using Recursion
function binarySearchs(arr, left, right, target) {
  if (left > right) {
    return -1;
  }
  let mid = Math.floor((left + right) / 2);
  if (arr[mid] === target) {
    return mid;
  } else if (arr[mid] > right) {
    return binarySearchs(arr, left, mid - 1, target);
  } else {
    return binarySearchs(arr, mid + 1, right, target);
  }
}

console.log(binarySearch([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 8));

// return the left most index of the target

function binarySearchLeft(arr, target) {
  let n = arr.length;
  let left = 0;
  let right = n - 1;
  let ans = -1;

  while (left <= right) {
    let mid = Math.floor((left + right) / 2);
    if (arr[mid] === target) {
      ans = mid;
      right = mid - 1;
    } else if (arr[mid] > target) {
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }
  return ans;
}

console.log(binarySearchLeft([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3));

// Time Complexity: O(log n)
// Space Complexity: O(1)

function sortedRotatedArray(nums, target) {
  let left = 0;
  let right = nums.length - 1;

  while (left <= right) {
    let mid = Math.floor((left + right) / 2);

    if (nums[mid] === target) {
      return mid;
    } else if (nums[left] <= nums[mid]) {
      if (nums[left] <= target && nums[mid] > target) {
        right = mid - 1;
      } else {
        left = mid + 1;
      }
    } else {
      if (target > nums[mid] && target <= nums[right]) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }
  }
  return -1;
}

console.log(sortedRotatedArray([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3));
// Time Complexity: O(log n)

function kthSmallestElementInMatrix(matrix, k) {
  let n = matrix.length;

  let left = matrix[0][0];
  let right = matrix[n - 1][n - 1];

  let res = right;
  while (left <= right) {
    let mid = Math.floor((left + right) / 2);

    if (isPossible(matrix, k, mid)) {
      res = mid;
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }
  return res;
}

function isPossible(matrix, k, mid) {
  let count = 0;
  let n = matrix.length;
  let c = n - 1;

  for (let i = 0; i < n; i++) {
    while (c >= 0 && matrix[i][c] > mid) {
      c--;
    }
    count += c + 1;
  }
  return count >= k;
}

console.log(
  kthSmallestElementInMatrix("Smallest", [
    [1, 5, 9],
    [10, 11, 13],
    [12, 13],
  ]),
);

function bookReading(n, h, a) {
  let left = 1;
  let right = Math.max(...a);
  let ans = right;
  let mid;

  while (left <= right) {
    mid = Math.floor((left + right) / 2);

    if (isPoss(a, h, mid) === true) {
      ans = mid;
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }
  return ans;
}

function isPoss(a, h, k) {
  let count = 0;

  for (let i = 0; i < a.length; i++) {
    count += Math.ceil(a[i] / k);
  }

  if (count <= h) {
    return true;
  } else {
    return false;
  }
}

console.log("Book Reading", bookReading(4, 8, [3, 6, 7, 11]));

// Which of the following statements about Binary Search is true?

// a)  time complexity is onabort(n)
// b) can't be impleted iteratively
// c) is recursive algorithm
// d) only for int arrays

function binarySearch12(arr, target) {
  let left = 0;
  let right = arr.length - 1;

  while (left <= right) {
    let mid = left + Math.floor((right - left) / 2);
    if (arr[mid] === target) {
      return mid;
    } else if (arr[mid] < target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }

  return -1;
}

let arr11 = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91];
const target = 23;
const result = binarySearch12(arr11, target);
console.log(result);

function peakElement(N, nums) {
  let left = 0;
  let right = N - 1;

  while (left <= right) {
    let mid = Math.floor((right + left) / 2);

    let leftValue = mid == 0 ? -Infinity : nums[mid - 1];
    let rightValue = mid == N - 1 ? -Infinity : nums[mid + 1];

    if (nums[mid] > leftValue && nums[mid] > rightValue) {
      return mid;
    } else if (nums[mid] < leftValue) {
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }
  return 0;
}

console.log("Peak Element", peakElement(4, [1, 2, 3, 1]));

function zeroOnes(n, arr) {
  let res = -1;
  let left = 0;
  let right = n - 1;
  let mid;

  while (left <= right) {
    mid = Math.floor((left + right) / 2);

    if (arr[mid] === 0) {
      left = mid + 1;
    } else {
      right = mid - 1;
      res = mid;
    }
  }

  return res;
}
console.log("Zero Ones", zeroOnes(4, [0, 0, 1, 1]));

function firstIndex(k, a) {
  let left = 0;
  let right = a.length - 1;

  while (left <= right) {
    let mid = Math.floor((left + right) / 2);

    if (a[mid] === k) {
      right = mid - 1;
    } else if (a[mid] > k) {
      // lessthan
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }
  return left;
}

function lastIndex(k, a) {
  let left = 0;
  let right = a.length - 1;

  while (left <= right) {
    let mid = Math.floor((left + right) / 2);

    if (a[mid] === k) {
      left = mid + 1;
    } else if (a[mid] > k) {
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }
  return right;
}

function countOccurances(n, k, a) {
  let first = firstIndex(k, a);

  let last = lastIndex(k, a);
  return last - first + 1;
}

console.log("countOccurances", countOccurances(5, 2, [-1, 2, 2, 4, 7]));
