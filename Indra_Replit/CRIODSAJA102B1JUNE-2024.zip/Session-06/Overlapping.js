// Partially overlaping intervals
// totally overlapping intervals
// non overlapping intervals


function mergeIntervals(n ,intervals) {
  intervals.sort((a,b) => a[0] - b[0]);

  let ans = [];
  let startA = intervals[0][0];
  let endA = intervals[0][1];

  for(let i = 1 ; i< n ; i++) {
    let startB = intervals[i][0];
    let endB = intervals[i][1];

    if(startB <= endA) {
      endA = Math.max(endA, endB);
    } else {
      ans.push([startA, endA]);
      startA = startB;
      endA = endB;
    }
  }

  ans.push([startA, endA]);
  return ans;
}