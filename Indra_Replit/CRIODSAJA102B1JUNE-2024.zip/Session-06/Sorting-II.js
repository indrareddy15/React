// Quick Sort Divide and Conquer

function partition(arr, left, right) {
  let patitionEle = arr[left];
  let i = left;

  for (let j = left; j <= right - 1; j++) {
    if (arr[j] < patitionEle) {
      [arr[i], arr[j]] = [arr[j], arr[i]];
      i++;
    }
  }
  [arr[i], arr[right]] = [arr[right], arr[i]];
  return i;
}

function quickSortImpl(arr, left, right) {
  if (left >= right) {
    return;
  }
  let pi = partition(arr, left, right);
  quickSortImpl(arr, left, pi - 1);
  quickSortImpl(arr, pi + 1, right);
}

function quickSort(n, arr) {
  quickSortImpl(arr, 0, n - 1);
  return arr;
}
