const seq = [
  {
    name: "John Doe",
    age: 30,
    gender: "male",
    occupation: "Engineer",
  },
  {
    name: "Jane Smith",
    age: 25,
    gender: "female",
    occupation: "Doctor",
  },
  {
    name: "Alex Johnson",
    age: 35,
    gender: "other",
    gender_description: "Non-binary",
    occupation: "Artist",
  },
  {
    name: "John Doe",
    age: 30,
    gender: "male",
    occupation: "Engineer",
  },
  {
    name: "Jane Smith",
    age: 25,
    gender: "female",
    occupation: "Doctor",
  },
  {
    name: "Alex Johnson",
    age: 35,
    gender: "other",
    gender_description: "Non-binary",
    occupation: "Artist",
  },
  {
    name: "John Doe",
    age: 30,
    gender: "male",
    occupation: "Engineer",
  },
  {
    name: "Jane Smith",
    age: 25,
    gender: "female",
    occupation: "Doctor",
  },
  {
    name: "Alex Johnson",
    age: 35,
    gender: "other",
    gender_description: "Non-binary",
    occupation: "Artist",
  },
];

function bt1(seq) {
  const filterMale = seq.filter((gen) => gen.gender === "male");
  console.log("Male", filterMale);
}

bt1(seq);

function btn2() {
  const filteredFemale = seq.filter((gen) => gen.gender === "female");
  console.log("female", filteredFemale);
}
btn2(seq);

