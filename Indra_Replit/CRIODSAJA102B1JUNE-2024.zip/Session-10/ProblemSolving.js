function twoNonRepeatingNumbers(N, nums) {
  let hashMap = new Map();
  for (let i = 0; i < N; i++) {
    if (hashMap.has(nums[i]) == false) {
      hashMap.set(nums[i], 1);
    } else {
      hashMap.set(nums[i], hashMap.get(nums[i]) + 1);
    }
  }
  let res = []
  for (let [key, value] of hashMap) {
    if (value === 1) {
      res.push(key);
    }
  }

  if(res[0] > res[1]) {
    let temp = res[0];
    res[0] = res[1];
    res[1] = temp;
  }
  return res

  nums.sort((a, b) => a - b);
  let left = 0;
  let right = 1;
  let ans = [];
}

console.log(twoNonRepeatingNumbers(8, [2, 3, 7, 9, 11, 2, 3, 11]));

function countConversionBits(a, b) {
  let xor = a ^ b;
  let count = 0n;
  while (xor !== 0n) {
    count += xor & 1n;
    xor >>= 1n;
  }
  return count;
}

console.log("countConversionBits", countConversionBits(29, 15));

function numberOfOneBits(n) {
  let count = 0;
  while (n != 0) {
    n = n & (n - 1n);
    count++;
  }
  return count;
}
console.log("numberOfOneBits", numberOfOneBits(5));
