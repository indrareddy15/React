// Bit stands for binary digit. A bit is the basic unit of information and can only have one of two possible values that is 0 or 1. In our world, we usually with numbers using the decimal base. In other words. we use the digit 0 to 9 However, there are other number representations that can be quite useful such as the binary number systems

// 0001 -1
// 0010 -2
// 0011 -3
// 0100 -4
// 0101 -5
// 0110 -6
// 0111 -7
// 0111 -8
// 1000 -9
// 1001 -10
// 1010 -11
// 1011 -12
// 1100 -13
// 1101 -14
// 1110 -15
// 1111 -16

// AND , OR , XOR
// shift operator
// left shift operator (<<)
// right shift operator (>>)
// comlement (~)  => 1010 => 0101

// console.log(~ 5)
// console.log(~ -5)

function checkSetBit(num, idx) {
  let mask = 1n << BigInt(idx);
  if ((num & mask) > 0) {
    return true;
  } else {
    return false;
  }
}

function setBit(num, idx) {
  let mask = 1n << BigInt(idx);
  return num | mask;
}

function swapAllOddAndEvenBits(n) {
  // Implement it here
  let ans = 0n;
  for (let i = 0; i < 32; i++) {
    if (checkSetBit(n, i) == true) {
      if (i % 2 !== 0) {
        ans = setBit(ans, i - 1);
      } else {
        ans = setBit(ans, i + 1);
      }
    }
  }
  return ans;
}

console.log(swapAllOddAndEvenBits(22));
console.log(swapAllOddAndEvenBits(13));

function checkSetBit(num, idx) {
  let mask = 1n << BigInt(idx);
  if ((BigInt(num) & mask) === 0n) {
    return false;
  }
  return true;
}

function setBit(num, idx) {
  let mask = 1n << BigInt(idx);
  return num | mask;
}

function reverseBits(n) {
  let left = 31;
  let right = 0;
  let ans = 0n;

  while (left >= right) {
    if (checkSetBit(n, left) == true) {
      ans = setBit(ans, right);
    }

    if (checkSetBit(n, right) == true) {
      ans = setBit(ans, left);
    }

    left--;
    right++;
  }
  return ans;
}

console.log("reverseBits", reverseBits(43261596));
