// Two Pointer
// arr should be sorted 
// burte force approach should