// Selection Sort
// let arr = [9, 4, 5, 11, 2] ==> [2, 4, 5, 9, 11]
// Iteration1: Find the minimum element from index 0 to n - 1 and swap it with the element at index 0
// Iteration2: Find the minimum element from index 1 to n - 1 and swap it with the element at index 1
// Iteration3: Find the minimum element from index 2 to n - 1 and swap it with the element at index 2
// Iteration4: Find the minimum element from index 3 to n - 1 and swap it with the element at index 3

function selectionSort(arr, n) {
  for (let i = 0; i < n - 1; i++) {
    let minIndex = i,
      min_ele = arr[i];
    // Find the index of the minimum element from index i to n - 1
    for (let j = i + 1; j < n; j++) {
      if (arr[j] < min_ele) {
        min_ele = arr[j];
        minIndex = j;
      }
    }
    let temp = arr[i];
    arr[i] = arr[minIndex];
    arr[minIndex] = temp;
  }
  return arr;
}

console.log("Selection Sort", selectionSort([9, 4, 5, 11, 2], 5));

// BubbleSort
function bubbleSort(arr, n) {
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        let temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
      }
    }
  }
  return arr;
}
console.log("Bubble Sort", bubbleSort([9, 4, 5, 11, 2], 5));

// Merge Sort
// Divid and Conquer Approach

function mergeSort(arr) {
  mergeSorting(arr, 0, arr.length - 1);
  return arr;
}

function mergeSorting(arr, left, right) {
  if (left >= right) {
    return;
  }

  let mid = Math.floor((left + right) / 2);
  mergeSorting(arr, left, mid);
  mergeSorting(arr, mid + 1, right);
  merge(arr, left, mid, right);
}

function merge(arr, left, mid, right) {
  let n1 = mid - left + 1;
  let n2 = right - mid;
  let arr1 = new Array(n1);
  let arr2 = new Array(n2);

  for (let i = 0; i < n1; i++) {
    arr1[i] = arr[left + i];
  }

  for (let i = 0; i < n2; i++) {
    arr2[i] = arr[mid + 1 + i];
  }

  let idx1 = 0,
    idx2 = 0,
    k = left;

  while (idx1 < n1 && idx2 < n2) {
    if (arr1[idx1] <= arr2[idx2]) {
      arr[k] = arr1[idx1];
      idx1++;
    } else {
      arr[k] = arr2[idx2];
      idx2++;
    }
    k++;
  }

  while (idx1 < n1) {
    arr[k] = arr1[idx1];
    idx1++;
    k++;
  }

  while (idx2 < n2) {
    arr[k] = arr2[idx2];
    idx2++;
    k++;
  }
}

console.log("Merge Sort:", mergeSort([9, 4, 5, 11, 2]));

function wigleSort(arr, n) {
  for (let i = 1; i <= n - 1; i += 2) {
    if (i - 1 >= 0 && arr[i - 1] > arr[i]) {
      [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]];
    }
    if (i + 1 < n && arr[i + 1] > arr[i]) {
      [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
    }
  }
  return arr;
}

console.log("Wiggle Sort", wigleSort([1, 5, 1, 1, 6, 4], 6));


function nextGreaterElementWithSameSetOfDigits(n) {
  let arr = n.toString().split("");


  let i = arr.length - 1;
  while (i > 0) {
    if (arr[i] < arr[i+1]) {
      break;
    }
    i--;
  }
  if (i < 0) {
    return -1;
  }
  let j = arr.length - 1;
  while (j > 0){
    if (arr[j] > arr[i]) {
      break;
    }
    j--;
  }
  [arr[i], arr[j]] = [arr[j], arr[i]];
  arr.sort((a, b) => a - b).reverse();
  let ans = Number(arr.join(""));
  return ans;
}
console.log(nextGreaterElementWithSameSetOfDigits(12))

function reverse(arr, start, end) {
    while (start < end) {
        [arr[start], arr[end]] = [arr[end], arr[start]];
        start++;
        end--;
    }
}

function data123(n) {
  let arr = n.toString().split("");

  let i = arr.length - 2;

  while (i >= 0 && arr[i] >= arr[i + 1]) {
      i--;
  }


  if (i < 0) {
      return -1;
  }

  let j = arr.length - 1;

  while (j >= 0 && arr[j] <= arr[i]) {
      j--;
  }

  [arr[i], arr[j]] = [arr[j], arr[i]];

  reverse(arr, i + 1, arr.length - 1);

  let ans = parseInt(arr.join(""));

  return ans;
}

console.log(data123(1243))


function minDiff(n,arr) {
  arr.sort((a,b) => a - b);
  let minDiff = Infinity;

  for(let i = 0 ; i < n - 1 ; i++) {
      let diff = arr[i + 1] - arr[i];
      if(diff < minDiff) {
          minDiff = diff;
      }
  }
  return minDiff;
}
console.log("minDiff", minDiff(3,[1,2,4]))


function sortArrayAbsolute(n,arr) {
  arr.sort((a,b) => Math.abs(a) - Math.abs(b));
  return arr;
}

console.log("sortArrayAbsolute", sortArrayAbsolute(5,[2,-5,1,-2,4]))
