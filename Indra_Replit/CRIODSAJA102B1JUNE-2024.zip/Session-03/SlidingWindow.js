// Sliding Window any problem with subarray we can use sliding window

//Find the subarray of size k with maximum sum.

// CONSTANT SIZE SLIDING WINDOW

//Brute Force Approach

function maxSumSubArray(n, arr, k) {
  let ans;
  for (let i = 0; i < n - k + 1; i++) {
    let currSum = 0;
    for (let j = i; j < i + k; j++) {
      currSum += arr[j];
    }
    ans = Math.max(ans, currSum);
  }
  return ans;
}

// let arr = [2, 1, 5, 1, 3, 2];
// let k = 3;
// let n = arr.length;

// let maxSum = maxSumSubArray(n, arr, k);
// console.log("Maximum sum of a subarray of length", k, "is:", maxSum);

// Sliding window approach
// Step 1:  Find the Sum of first subarray
// Step 2: Increment your left and right both and find the new sum using the previous window's sum
// Step 3: Compare the new sum with the maximum sum

// let ans = Number.NEGATIVE_INFINITY;

function maxSubArray(n, arr, k) {
  let left = 0;
  let right = k - 1;
  let curSum = 0;

  for (let i = 0; i < k; i++) {
    curSum += arr[i];
  }
  let ans = curSum;
  left++;
  right++;

  while (right < n) {
    // or left < k
    curSum = curSum - arr[left - 1] + arr[right];
    if (curSum > ans) {
      ans = curSum;
    }
    left++;
    right++;
  }
  return ans;
}
// let arr = [2, 1, 5, 1, 3, 2];
// let k = 3;
// let n = arr.length;

// let maxSum = maxSubArray(n, arr, k);
// console.log("Maximum sum of a subarray of length", k, "is:", maxSum);

// For max muliplucation of subarray
function maxMulSubArray(n, arr, k) {
  let left = 0;
  let right = k - 1;
  let curSum = 0;

  for (let i = 0; i < k; i++) {
    curSum += arr[i];
  }
  let ans = curSum;
  left++;
  right++;

  while (right < n) {
    // or left < k
    curSum = curSum - arr[left - 1] + arr[right];
    if (curSum > ans) {
      ans = curSum;
    }
    left++;
    right++;
  }
  return ans;
}
let arr = [2, 1, 5, 1, 3, 2];
let k = 3;
let n = arr.length;

// let maxSum = maxSubArray(n, arr, k);
// console.log("Maximum Mul of a subarray of length", k, "is:", maxSum);

// VARIABLE SIZE SLIDING WINDOW

// Find the largesr subarray having at most k distinct elements / negaviive elements / postive elements / zero sum subarray

// [2,4,2,2,6,7], k = 2

// [6,7], [2,4], [2,4,2,2]

// Template of variable size of sliding window

// Find the Logest subarray with at most K distinct charcaters

function longestSubArray(s, k) {
  let left = 0;
  let right = 0;
  let ans = 0;

  let hashMap = new Map();

  while (right < s.length) {
    if (hashMap.has(s[right]) == false) {
      hashMap.set(s[right], 1);
    } else {
      hashMap.set(s[right], hashMap.get(s[right]) + 1);
    }

    while (hashMap.size > k) {
      hashMap.set(s[left], hashMap.get(s[left]) - 1);

      if (hashMap.get(s[left]) == 0) hashMap.delete(s[left]);
      left++;
    }
    ans = Math.max(ans, right - left + 1);
    right++;
  }
  return ans;
}
let s = "eceba";
let k1 = 2;
let ans = longestSubArray(s, k1);
console.log(ans);

// Quiz O1
function maxSumSubarray(nums, k) {
  let maxSum = 0;
  let currentSum = nums.slice(0, k).reduce((acc, num) => acc + num, 0);
  maxSum = currentSum;

  for (let i = k; i < nums.length; i++) {
    currentSum += nums[i] - nums[i - k];
    maxSum = Math.max(maxSum, currentSum);
  }

  return maxSum;
}

let nums = [2, 3, 5, 1, 6, 4];
let k2 = 3;
console.log(maxSumSubarray(nums, k2));

// Quiz O2
function minWindowSubstring(s, t) {
  let tFreq = new Array(128).fill(0);
  for (let c of t) {
    tFreq[c.charCodeAt(0)]++;
  }

  let left = 0,
    right = 0,
    count = t.length;
  let minLength = Infinity,
    minStart = 0;

  while (right < s.length) {
    if (tFreq[s.charCodeAt(right++)]-- > 0) {
      count--;
    }

    while (count === 0) {
      if (right - left < minLength) {
        minLength = right - left;
        minStart = left;
      }

      if (tFreq[s.charCodeAt(left++)]++ === 0) {
        count++;
      }
    }
  }

  return minLength === Infinity ? "" : s.substr(minStart, minLength);
}

const s1 = "ADOBECODEBANC";
const t = "ABC";
console.log(minWindowSubstring(s1, t));

// Quiz O3
function findSubarraySum(nums, target) {
  let left = 0;
  let right = 0;
  let currentSum = 0;

  while (right < nums.length) {
    currentSum += nums[right];

    while (currentSum > target) {
      currentSum -= nums[left];
      left++;
    }

    if (currentSum === target) {
      return [left, right];
    }

    right++;
  }

  return [-1, -1];
}

const nums1 = [2, 4, 7, 11, 15];
const target = 18;
const indices = findSubarraySum(nums1, target);
console.log(`Start index: ${indices[0]}`);
console.log(`End index: ${indices[1]}`);

function largestSubArraySum(n, arr) {
  let hashMap = new Map();

  hashMap.set(0, -1);

  let sum = 0;

  let ansLeft = -1;
  let ansRight = -2;

  for (let right = 0; right < n; right++) {
    sum += arr[right];

    if (hashMap.has(sum)) {
      let left = hashMap.get(sum) + 1;

      if (right - left + 1 > ansRight - ansLeft + 1) {
        ansRight = right;
        ansLeft = left;
      }
    } else {
      hashMap.set(sum, right);
    }
  }

  if (ansLeft != -1) {
    let res = arr.slice(ansLeft, ansRight + 1);
    return res;
  }

  return [-1];
}
