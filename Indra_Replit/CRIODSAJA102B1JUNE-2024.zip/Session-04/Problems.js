// Add Hock Problems that doesn't necessarily requieres any pre-knowldedge of algorithm

// Martrix
// 2D Array: arrays inside arrays

// Setp1: Fill the element of the topmost unfilled row in rightward direction
// Step2: Fill the element of the rightmost unfilled column in downward direction
// Step3: Fill the element of the bottommost unfilled row in leftward direction
// Step4: Fill the element of the leftmost unfilled column in upward direction

// Step5: Repeat the steps from 1 to 4 until all the elements are filled

function sprialMatrix(n) {
  if (n === 0) return []; // Handle edge case when n is 0

  let top = 0;
  let bottom = n - 1;
  let left = 0;
  let right = n - 1;
  let num = 1;

  let arr = [];
  for (let i = 0; i < n; i++) {
    // arr[i] = new Array(n)
    arr.push(new Array(n));
  }

  while (num <= n * n) {
    for (let i = left; i <= right; i++) {
      arr[top][i] = num;
      num++;
    }
    top++;

    for (let i = top; i <= bottom; i++) {
      arr[i][right] = num;
      num++;
    }
    right--;

    for (let i = right; i >= left; i--) {
      arr[bottom][i] = num;
      num++;
    }
    bottom--;

    for (let i = bottom; i >= top; i--) {
      arr[i][left] = num;
      num++;
    }
    left++;
  }
  return arr;
}

// let n = 3;
// let matrix = sprialMatrix(n);
// console.log(matrix);

function maxProfit(prices) {
  let maxProfit = 0;
  let currentProfit = 0;

  for (let i = 1; i < prices.length; i++) {
    if (prices[i] > prices[i - 1]) {
      currentProfit += prices[i] - prices[i - 1];
    } else {
      maxProfit += currentProfit;
      currentProfit = 0;
    }
  }

  // Add the last accumulated profit
  maxProfit += currentProfit;

  return maxProfit;
}

// // Example usage:
// let prices1 = [7, 1, 5, 3, 6, 4];
// console.log(maxProfit(prices1)); // Output: 7

// let prices2 = [1, 2, 3, 4, 5];
// console.log(maxProfit(prices2)); // Output: 4

// let prices3 = [7, 6, 4, 3, 1];
// console.log(maxProfit(prices3)); // Output: 0

function isPliandrome(s) {
  // let left = 0 ;
  // let right = str.length - 1;

  // while (left < right) {
  //   if (str[left] !== str[right]) {
  //     return false;
  //   }
  //   left++;
  //   right--;
  // }
  // return true;

  let hashMap = new Map();

  for (let i = 0; i < s.length; i++) {
    if (hashMap.has(s[i]) == false) {
      hashMap.set(s[i], 1);
    } else {
      hashMap.set(s[i], hashMap.get(s[i]) + 1);
    }
  }

  let count = 0;
  for (let [key, value] of hashMap) {
    if (value % 2 != 0) {
      count++;
    }
  }

  if (count <= 1) {
    return true;
  } else {
    return false;
  }
}

let str = "nnaamm";
let newStr = isPliandrome(str);
console.log(newStr);

function setMatrixZeros(matrix) {
  let m = matrix.lenght;
  let n = matrix[0].length;

  let row = new Array(m).fill(false);

  let col = new Array(n).fill(false);

  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      if (matrix[i][j] == 0) {
        row[i] = true;
        col[j] = true;
      }
    }
  }

  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      if (row[i] === true || col[j] === true) {
        matrix[i][j] = 0;
      }
    }
  }
  return matrix;
}

function firstMissingPositive(n, arr) {
  let hashMap = new Map();

  for (let i = 0; i < n; i++) {
    hashMap.set(arr[i], 1);
  }

  for (let i = 1; i <= n; i++) {
    if (!hashMap.has(i)) {
      return i;
    }
  }
  return n + 1;
}

function firstMissingPositive(n, arr) {
  let hashSet = new Set();

  for (let i = 0; i < n; i++) {
    hashSet.add(arr[i]);
  }
  for (let i = 1; i <= n; i++) {
    if (!hashSet.has(i)) {
      return i;
    }
  }
  return n + 1;
}

function matrixMultlplication(n1, m1, n2, m2, grid1, grid2) {
  let grid3 = new Array(n1);

  for (let i = 0; i < n1; i++) {
    grid3[i] = new Array(m2).fill(0);
  }

  for (let r = 0; r < n1; r++) {
    for (let c = 0; c < m2; c++) {
      for (let k = 0; k < m1; k++) {
        grid3[r][c] += grid1[r][k] * grid2[k][c];
      }
    }
  }
  return grid3;
}

function stringPermutation(n, s, arr) {
  let res = new Array(n).fill(0);

  for (let i = 0; i <= n - 1; i++) {
    let ch = s.charAt(i);

    let idx = arr[i] - 1;

    res[idx] = ch;
  }
  return res.join("");
}
let n = 4;
let s = "abcd";
let arr = [2, 4, 3, 1];

console.log(stringPermutation(n, s, arr));
