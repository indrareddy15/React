async function tvMazeTabs() {
  try {
    const response = await fetch("https://api.tvmaze.com/shows");
    const data = await response.json();
    console.log(data.length);
  } catch (err) {
    console.log(err);
  }
}

tvMazeTabs();
