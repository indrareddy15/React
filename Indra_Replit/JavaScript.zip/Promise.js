// Promise in Javascript
// Start with backdrops
// Basically Javascript is single threaded lanugage. it can only handle synchrnous operations.
// there few ways to handle asynchronous operations in javascript. one of the way using callbacks.
// Promises are objects that represent the eventual completion or failure of an asynchronous operation.
// Promises are used to handle asynchronous operations in Javascript.
// JavaScript promises can be in one of three possible states.pending , fulfilled , rejected

// To create a promise, you need to create an instance object using the Promise constructor function

let myPromise = new Promise((resolve, reject) => {
  setTimeout(() => {
    let condition = false;

    if (condition) {
      resolve("Promise is Resolved");
    } else {
      reject("Promise is Rejected");
    }
  }, 2000);
});

// How to Attach a Callback to a Promise
// To create a callback for a promise, you need to use the .then() method.
// This method takes in two callback functions.
// The first function runs if the promise is resolved, while the second function runs if the promise is rejected.
myPromise
  .then((message) => console.log(message))
  .catch((error) => console.error(error));

let ourPromise = new Promise((res, rej) => {
  try {
    setTimeout(() => {
      let condi = true;
      if (condi) {
        res("Promise is Resolved");
      } else {
        rej("Promise is Rejected");
      }
    }, 2000);
  } catch (err) {
    console.log(err);
  }
});

// ourPromise.then((msg) => console.log(msg)).catch((err) => console.error(err));

// Now assume you want to perform many other fetch operations, but each operation must be successful for the next one to run.
// This is useful if the data you need must come in a certain order and cannot be scattered.
// For example, you might run into this situation if the result of the next operation depends on the result of the previous one.
// In this case, your success callbacks would have their own success callbacks, which is important because you need to use the results if they come in.


const mathPromise = new Promise((resolve, reject) => {
  try {
    setTimeout(() => {
      let num = 5;
      if (num) {
        resolve("MathPromise is Resolved");
      } else {
        reject("MathPromise is Rejected");
      }
    }, 2000);
  } catch (err) {
    console.error(err);
  }
});

function handleReslove(value) {
  console.log(value);
}
function handleReject(error) {
  console.error(error);
}

mathPromise.then(handleReslove, handleReject);




console.log("Promise log Res",Promise)