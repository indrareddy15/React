// React memo
// Usecallback
// useMemo

// useReducer


// https://trio.dev/7-top-react-state-management-libraries/

// https://www.youtube.com/watch?v=3ZvJLJb2m-

const ListComponent = ({ items }) => {
  const processedItems = processItems(items); // Expensive computation

  return (
    <ul>
      {processedItems.map(item => (
        <li key={item.id}>{item.name}</li>
      ))}
    </ul>
  );
};

const processItems = (items) => {
  // Expensive computation
  // Imagine some heavy processing here
  return items.map(item => ({ id: item.id, name: item.name.toUpperCase() }));
};

export default ListComponent;