// Fake URLs for demonstration
// Different apis have different datatypes
const urls = [
  "https://fakestoreapi.com/products",
  "https://fakestoreapi.com/carts",
  "https://jsonplaceholder.typicode.com/posts",
];

function fetchResourcesSequentially(urls) {
  // Start with a resolved Promise
  return urls.reduce((promiseChain, url) => {
    return promiseChain
      .then((result) => {
        console.log(result); // Log result of previous fetch
        return fetchResource(url); // Fetch the next resource
      })
      .then((result) => {
        console.log(`Fetched: ${result}`);
        return result;
      });
  }, Promise.resolve());
}

fetchResourcesSequentially(urls)
  .then(() => {
    console.log("All fetch operations completed successfully.");
  })
  .catch((error) => {
    console.error("An error occurred during fetch operations:", error);
  });