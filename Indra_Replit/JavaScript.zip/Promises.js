// function fetchCountries() {
//   let fetchApiData = fetch("https://restcountries.com/v3.1/all");
//   return fetchApiData
//     .then((res) => {
//       if (!res.ok) {
//         throw new Error("Network response was not ok " + response.statusText);
//       }

//       return res.json();
//     })
//     .then((data) => {
//       console.log(data);
//       return data;
//     })
//     .catch((error) => {
//       console.error(
//         "There has been a problem with your fetch operation:",
//         error,
//       );
//     });
// }

// fetchCountries();

function fetchApi() {
  return fetch("https://restcountries.com/v3.1/all")
    .then((res) => {
      if (!res.ok) {
        throw new Error("Error in Network" + res.statusText);
      }
      return res.json();
    })
    .then((data) => {
      console.log(data);
      return data;
    })
    .catch((error) => {
      console.error(error);
    });
}
fetchApi();
