// const axios = require('axios');

// async function axiosGet() {
//   try {
//     let response = await axios.get("https://fakestoreapi.com/users")
//     console.log(response.data)
//   } catch(err) {
//     console.error(err)
//   }

// }
// axiosGet()

// async function fetchAPI() {
//   try {
//     let response = await fetch("https://fakestoreapi.com/users")
//     let data = await response.json()
//     console.log(data)
//   } catch(err) {
//     console.error(err)
//   }
// }
// fetchAPI()

// const promise = new Promise((response, reject) => {
//   try {
//     setTimeout(() => {
//       const condition = true;
//       if (condition) {
//         response("I am resolved");
//       } else {
//         reject("I am rejected");
//       }
//     }, 2000);
//   } catch (error) {
//     reject(error);
//   }
// });

promise
  .then((message) => console.log(message))
  .catch((error) => console.log(error));

const promise1 = new Promise((res, rej) => {
  setTimeout(() => {
    res("Hello Promise 1");
  }, 1000);
});

const promise2 = new Promise((res, rej) => {
  setTimeout(() => {
    rej("Hello Promise 2");
  }, 2000);
});

const promise3 = new Promise((res, rej) => {
  setTimeout(() => {
    res("Hello Promise 3");
  }, 3000);
});

// promise1.then((msg) => console.log(msg));
// promise2.then((msg) => console.log(msg));
// promise3.then((msg) => console.log(msg));

Promise.all([promise1, promise2, promise3])
  .then((msg) => console.log(msg))
  .catch((err) => console.log(err));

// Promise all
// For example if we call multiple api at a time by using promise all then it will return all the data in the form of array.
// if rej any one api fails that will return error and will not return the data of the other api.

// Promise.allSettled([promise1, promise2, promise3])
//   .then((msg) => console.log(msg))
//   .catch((err) => console.log(err));

// Promise allSatelled
// For example if we call multiple api at a time by using promise allSatelled then it will return all with the status of the api.
// if rej any one api fails that will return error but will get the data of the other apis in the form of array

const fetchPost = async () => {
  try {
    const data = await fetch("https://jsonplaceholder.typicode.com/posts");
    const response = await data.json();
    // console.log(response)
    return { status: "fullfilled", response };
  } catch (err) {
    // console.error(err);
    return { status: "rejected", reason: err };
  }
};

const fetchUser = async () => {
  try {
    const data = await fetch("https://jsonplaceholder.typicode.com/users");
    const response = await data.json();
    // console.log(response)
    return { status: "fullfilled", response };
  } catch (err) {
    // console.error(err);
    return { status: "rejected", reason: err };
  }
};

const fetchCart = async () => {
  try {
    const data = await fetch("https://jsonplaceholder.typicode.com/carts");
    const response = await data.json();
    // console.log(response)
    return { status: "fullfilled", response };
  } catch (err) {
    // console.error(err);
    return { status: "rejected", reason: err };
  }
};

Promise.allSettled([fetchPost(), fetchUser(), fetchCart()])
  .then((msg) =>
    msg.forEach((result, idx) => {
      if (result.status === "fulfilled") {
        console.log(result.value);
      } else {
        console.log(result.reason);
      }
    }),
  )
  .catch((err) => console.log(err));

function outer(o) {
  return (function inner(i) {
    console.log(i);
  })(1);
}
