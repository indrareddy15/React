const shallowOriginal = { a: 1, b: { c: 2 } };
const shallowCopy = Object.assign({}, shallowOriginal);
console.log("shallowCopy", shallowCopy);
shallowCopy.b.c = 3;
// Definition: A shallow copy creates a new object, but it copies only the references to the nested objects. The top-level structure is duplicated, but nested objects are still referenced by the top-level object.

console.log(shallowOriginal.b.c); // 3 (changed in both)

const deepOriginal = { a: 1, b: { c: 2 } };
const deepCopy = JSON.parse(JSON.stringify(deepOriginal));
console.log("deepCopy", deepCopy);
deepCopy.b.c = 3;
// Definition: A deep copy creates a new object, and recursively copies the nested objects as well. T Changes made to the deep copy do not affect the original object.
console.log(deepOriginal.b.c); // 2 (unchanged)

// In a shallow copy, nested objects are still linked to the original; in a deep copy, they are entirely independent.

// Shallow copies are generally faster and use less memory than deep copies, especially for large objects.

// Use shallow copy when the object structure is simple or when you don’t need to modify nested objects. // Use deep copy when you need complete independence from the original object.



const obj1 = { a: 1, b: { c: 2 } };
const obj2 = Object.assign({}, obj1)
console.log(obj2)


