const arr1 = [1, 2, 3, 4, 5];
const arr2 = [6, 7, 8, 9, 10];

let arr3 = arr1.concat(arr2);
// Return new array comprised of this array joined with other array(s) and/or value(s).
console.log("concat", arr3);

let arr4 = arr1.every((n) => n % 2 === 0);
// Return true if every element in this array satisfies the provided testing function.
console.log("every", arr4);

let arr5 = arr2.filter((n) => n % 2 === 0);
// Return new array containing all elements of the array for which the provided filtering function returns true.
console.log("filter", arr5);

// const arr6 = arr1.forEach((n) => console.log("forEach", n));
const arr06 = arr1.forEach((n) => n);
console.log("forEach", arr1);
// Call a defined callback function on each element of an array, and return the array.

let arr7 = arr2.map((n) => n);
// Create a new array with the results of calling a provided function on every element in the calling array.
console.log("log_map", arr2);

let arr8 = arr1.indexOf(3);
// Return the first (least) index of an element within the array equal to the specified value, or -1 if none is found.
console.log("indexOf", arr8);

let arr9 = arr1.join("");
// Join all elements of an array into a string.
console.log("join", arr9);

let arr10 = arr1.lastIndexOf(5);
// Return the last (greatest) index of an element within the array equal to the specified value, or -1 if none is found.
console.log("lastIndexOf", arr10);

let arr11 = arr1.push("newele");
// Add one or more elements to the end of an array and return the new length of the array.
console.log("Push", arr1);

let arr12 = arr1.pop("newele");
// Remove the last element from an array and return that element.
console.log("POP", arr1);

let arr13 = arr1.reduce((a, b) => {
  return a + b;
});
// Reduce the values of an array to a single value (going left-to-right).
console.log("reduce", arr13);

let arr14 = arr1.reduceRight((a, b) => {
  return a + b;
});
// Reduce the values of an array to a single value (going right-to-left).
console.log("reduceRight", arr14);

let arr15 = arr1.reverse();
// Reverse the order of the elements in an array -- the first becomes the last, and the last becomes the first.
console.log("reverse", arr15);

let arr16 = arr1.unshift(10);
// Add one or more elements to the beginning of an array and return the new length of the array.
console.log("unshift", arr1);

let arr17 = arr1.shift(10);
// Remove the first element from an array and return that element.
console.log("shift", arr1);

let arr18 = arr1.slice(1, 3);
// Return a shallow copy of a portion of an array into a new array object selected from begin to end (end not included).
console.log("slice", arr18);

let arr19 = arr1.some((n) => n % 2 === 0);
// Determine whether the given callback function returns a true value for any element of the array.
console.log("some", arr19);

let arr20 = arr1.sort();
// Sort the elements of an array in place and return the array.
console.log("sort", arr20);

let arr21 = arr1.splice(1, 2, "newele");
// Add/remove elements from an array and, if necessary, insert missing elements to make it the specified length.
console.log("splice", arr1);

let arr22 = arr1.toString();
// Convert an array to a string, and return the result.
console.log("toString", arr22);
