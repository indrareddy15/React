async function fetchData() {
  try {
    const apiData = await fetch(
      "https://qtify-backend-labs.crio.do/albums/top",
    );
    const apiResponse = await apiData.json();
    // console.log(apiResponse)
    console.log(apiResponse.length)
  } catch (err) {
    console.error(err);
  }
}

fetchData()