// Debouncing and Throttling is used used for performance optimization of web app.
// Debouncing is used to prevent the function from being called too many times in a short period of time
// Throttling is used to prevent the function from being called too many times in a long period of time.

let counter = 0;
const getData = () => {
  // class an API and gets the data
  console.log("Fetching Data...", counter++);
};

function debounceMethod(fn, delay) {
  let timer;
  return function () {
    let context = this;
    args = arguments;
    clearTimeout(timer);
    timer = setTimeout(() => {
      getData.apply(context, arguments);
    }, delay);
  };
}

let debounce = debounceMethod(getData, 300);
console.log(debounce());
1;

// react

import React, { useState, useRef } from "react";

const SearchInput = () => {
  const [query, setQuery] = useState("");
  const timeoutRef = useRef(null);

  const handleChange = (e) => {
    const value = e.target.value;

    // Clear the previous timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Set a new timeout
    timeoutRef.current = setTimeout(() => {
      setQuery(value);
      // Simulate an API call or other side-effect
      console.log("Search query submitted:", value);
    }, 500); // 500ms delay
  };

  return (
    <div>
      <input type="text" placeholder="Search..." onChange={handleChange} />
      <p>Search query: {query}</p>
    </div>
  );
};

export default SearchInput;
