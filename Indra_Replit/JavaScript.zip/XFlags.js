async function fecthFlags() {
  try {
    let apiData = await fetch(
      "https://xcountries-backend.azurewebsites.net/all",
    );
    const flagResponse = await apiData.json();
    console.log(flagResponse);
  } catch (error) {
    console.log(error);
  }
}

fecthFlags();
