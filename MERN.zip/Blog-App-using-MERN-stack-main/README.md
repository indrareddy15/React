# Blog-App-using-MERN-stack
Blog App also visit https://github.com/khushi2706/E-commerce-website-using-React-Redux 

# Functionalities 
- Authentication 
- Create blog
- Delete Blog
- Update Blog
- View other user blog

# Screenshots
![Screenshot (35)](https://user-images.githubusercontent.com/67452985/172217325-4378400e-60a0-4364-aadb-89e900886a1c.png)
![Screenshot (36)](https://user-images.githubusercontent.com/67452985/172217368-76264e6e-8373-484d-9cd0-3af5920754b1.png)
![screencapture-localhost-3000-blogs-add-2022-05-28-18_41_43](https://user-images.githubusercontent.com/67452985/172217649-238abde0-1b29-40fe-a46e-1b5bb03678c8.png)
